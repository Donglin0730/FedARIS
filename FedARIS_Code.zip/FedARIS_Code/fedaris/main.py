"""FedARIS training entry point.

The implementation keeps three decisions separate: risk estimation, source-
specific supervision construction, and reliability-aware aggregation.  This
separation is important because observed-label corrections and native
unlabeled pseudo labels have different error mechanisms and acceptance rules.
"""

import copy
import os
from datetime import datetime

import numpy as np
import torch

from model.build_model import build_model
from util.dataset import prepare_scenario
from util.fedavg import FedAvg
from util.local_training import FedNSLocalUpdate
from util.metrics import ClassificationTracker
from util.options import args_parser
from util.sampling import (
    NoReplacementClientSampler,
    fixed_client_probes,
    write_log,
)
from util.util import (
    FedNSState,
    collect_fedns_observation,
    collect_teacher_prediction,
    make_ema_teacher,
    pseudo_coefficients,
    reliability_aggregation_masses,
    unlabeled_recovery_start_round,
    update_ema_teacher,
)


METHOD_NAME = 'fedaris'


def seed_everything(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def capture_rng_state():
    state = {
        'numpy': np.random.get_state(),
        'torch': torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state['cuda'] = torch.cuda.get_rng_state_all()
    return state


def restore_rng_state(state):
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch'])
    if state.get('cuda') is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state['cuda'])


def isolated_call(function):
    """Keep diagnostics from changing the local-optimization RNG stream."""
    rng_state = capture_rng_state()
    try:
        return function()
    finally:
        restore_rng_state(rng_state)


def soft_label_arrays(labeled_indices, visible_targets, soft_plans,
                     num_classes):
    """Merge per-plan soft corrections into the local labeled order."""
    labeled_indices = np.asarray(labeled_indices, dtype=np.int64)
    labels = np.asarray(visible_targets, dtype=np.int64)[labeled_indices]
    targets = np.eye(int(num_classes), dtype=np.float32)[labels]
    alpha = np.zeros(len(labeled_indices), dtype=np.float32)
    positions = {
        int(sample_index): position
        for position, sample_index in enumerate(labeled_indices)
    }
    for plan in soft_plans:
        indices = np.asarray(plan['indices'], dtype=np.int64)
        applied = np.asarray(plan['applied'], dtype=bool)
        plan_targets = np.asarray(plan['soft_targets'], dtype=np.float32)
        plan_alpha = np.asarray(plan['alpha'], dtype=np.float32)
        for plan_position in np.where(applied)[0]:
            local_position = positions.get(int(indices[plan_position]))
            if local_position is None:
                continue
            targets[local_position] = plan_targets[plan_position]
            alpha[local_position] = plan_alpha[plan_position]
    return targets, alpha


def run_training(args, scenario, log_path):
    """Run one complete federated experiment under a frozen data scenario.

    The EMA teacher builds all diagnostic and pseudo-label plans before local
    SGD.  Each selected client therefore consumes a fixed plan, which prevents
    client execution order from changing the supervision used in the round.
    """
    config = args.fedns
    dataset_train = scenario['train']
    labeled_users = scenario['labeled_users']
    unlabeled_users = scenario['unlabeled_users']
    clients_per_round = min(
        max(int(args.frac * args.num_users), 1), args.num_users)
    coverage_rounds = int(np.ceil(args.num_users / clients_per_round))
    if config.refresh_interval < coverage_rounds:
        raise ValueError(
            '--refresh_interval must fit one no-replacement coverage cycle.')

    model = build_model(args)
    teacher = make_ema_teacher(model)
    state = FedNSState(args, len(dataset_train))
    state.initialize_sources(labeled_users, unlabeled_users)
    warmup_sampler = NoReplacementClientSampler(args.num_users, args.seed + 101)
    refresh_sampler = NoReplacementClientSampler(args.num_users, args.seed + 211)
    selection_rng = np.random.RandomState(args.seed + 307)
    probes = fixed_client_probes(
        labeled_users, config.diagnostic_probe_size, args.seed + 401)
    tracker = ClassificationTracker(log_path)
    for round_index in range(args.rounds):
        in_warmup = round_index < args.warmup_rounds
        refresh_offset = (
            (round_index - args.warmup_rounds) % config.refresh_interval
            if not in_warmup else -1)
        in_refresh = not in_warmup and refresh_offset < coverage_rounds

        if in_warmup:
            selected = warmup_sampler.sample(clients_per_round)
        elif in_refresh:
            selected = refresh_sampler.sample(clients_per_round)
        else:
            selected = selection_rng.choice(
                args.num_users, clients_per_round, replace=False)

        local_weights = []
        effective_masses = []
        round_clients = []
        round_plans = []
        risk_candidate_plans = []
        unlabeled_active = (
            round_index >= unlabeled_recovery_start_round(args))
        soft_correction_active = round_index >= (
            int(args.warmup_rounds) + int(config.risk_soft_start_delay))
        # R_i has its own start boundary. It should not wait for U_i to
        # activate, otherwise a long unlabeled delay also delays label repair.
        risk_monitor_active = round_index >= (
            int(args.warmup_rounds) + int(config.risk_recovery_delay))
        risk_detection_active = risk_monitor_active or soft_correction_active
        risk_training_active = (
            risk_monitor_active
            and state.risk_start_round is not None
            and round_index >= state.risk_start_round)
        source_weights = pseudo_coefficients(
            args, round_index, state.risk_start_round)

        for raw_client_id in selected:
            client_id = int(raw_client_id)
            labeled = np.asarray(
                sorted(labeled_users[client_id]), dtype=np.int64)
            unlabeled = np.asarray(
                sorted(unlabeled_users[client_id]), dtype=np.int64)

            probe_observation = isolated_call(lambda: collect_fedns_observation(
                teacher, dataset_train, probes[client_id], args,
                observed_targets=scenario['visible_targets']))
            state.observe_client(client_id, probe_observation['mean_loss'])

            if not in_warmup:
                # A refresh already pays for a full-client forward pass. Reuse
                # it for sample risk instead of updating only the 20% probe.
                diagnostic_indices = (
                    labeled if in_refresh else
                    state.diagnostic_indices(client_id, labeled))
                diagnostic = isolated_call(lambda: collect_fedns_observation(
                    teacher, dataset_train, diagnostic_indices, args,
                    observed_targets=scenario['visible_targets']))
                state.observe_labeled(diagnostic, client_id=client_id)

            pseudo_plans = {}
            soft_plans = []
            if risk_detection_active:
                risk_indices = state.risk_indices(labeled)
                if len(risk_indices):
                    risk_prediction = isolated_call(
                        lambda: collect_teacher_prediction(
                            teacher, dataset_train, risk_indices, args))
                    risk_plan = state.build_pseudo_plan(
                        risk_prediction, 'risk',
                        observed_targets=scenario['visible_targets'],
                        client_is_high_risk=bool(
                            state.client_high_risk[client_id]),
                        commit=risk_training_active)
                    if risk_monitor_active:
                        risk_candidate_plans.append(risk_plan)
                    if risk_training_active:
                        pseudo_plans['risk'] = risk_plan
                    if soft_correction_active:
                        soft_plans.append(
                            state.build_soft_correction_plan(
                                risk_plan,
                                scenario['visible_targets'],
                                client_is_high_risk=bool(
                                    state.client_high_risk[client_id]),
                            ))
            if unlabeled_active and len(unlabeled):
                unlabeled_prediction = isolated_call(
                    lambda: collect_teacher_prediction(
                        teacher, dataset_train, unlabeled, args))
                pseudo_plans['unlabeled'] = state.build_pseudo_plan(
                    unlabeled_prediction, 'unlabeled')
            round_plans.extend(pseudo_plans.values())
            round_clients.append({
                'client_id': client_id,
                'labeled': labeled,
                'pseudo_plans': pseudo_plans,
                'soft_plans': soft_plans,
            })

        # Select U_i globally across this communication round. The local
        # updates then consume the already frozen, order-invariant plans.
        readiness = state.observe_risk_readiness(
            risk_candidate_plans, round_index)
        state.commit_unlabeled_round(round_plans)

        for client in round_clients:
            client_id = client['client_id']
            labeled = client['labeled']
            observed_weights = state.observed_weights(labeled)
            soft_targets, soft_alpha = soft_label_arrays(
                labeled,
                scenario['visible_targets'],
                client['soft_plans'],
                args.num_classes,
            )
            local = FedNSLocalUpdate(
                args,
                dataset_train,
                labeled,
                observed_weights,
                pseudo_plans=client['pseudo_plans'],
                soft_targets=soft_targets,
                soft_alpha=soft_alpha,
                augmentation_enabled=not in_warmup,
                supervised_robustness=(
                    0.0 if in_warmup else state.client_risk[client_id]),
                robust_loss_q=config.robust_loss_q,
            )
            result = local.update_weights(
                copy.deepcopy(model).to(args.device), source_weights)
            local_weights.append(result['weights'])
            effective_masses.append(result['effective_mass'])

        state.refresh_client_risks(selected)
        aggregate_masses = reliability_aggregation_masses(
            effective_masses,
            state.client_risk[np.asarray(selected, dtype=np.int64)],
            config.aggregation_strength,
            config.reliability_floor,
        )
        model.load_state_dict(FedAvg(local_weights, aggregate_masses))
        update_ema_teacher(teacher, model, config.teacher_ema)
        student_metrics, teacher_metrics = tracker.record(
            round_index, model, teacher, scenario['test'], args)
        pseudo_parts = []
        for source in ('risk', 'unlabeled'):
            source_plans = [
                plan for plan in round_plans if plan['source'] == source]
            if source_plans:
                total = sum(len(plan['indices']) for plan in source_plans)
                accepted = sum(
                    int(np.asarray(plan['accepted']).sum())
                    for plan in source_plans)
                pseudo_parts.append(f'{source}={accepted}/{total}')
        if risk_monitor_active and not risk_training_active:
            pseudo_parts.append(
                f'risk-ready={readiness["mature"]}/'
                f'{readiness["total"]}'
                f'[{readiness["streak"]}/{config.risk_ready_rounds}]')
        if soft_correction_active:
            soft_count = sum(
                int(np.asarray(plan['applied'], dtype=bool).sum())
                for client in round_clients
                for plan in client['soft_plans'])
            pseudo_parts.append(f'soft-risk={soft_count}')
        if readiness['activated']:
            pseudo_parts.append(
                f'risk-start=round-{readiness["start_round"] + 1}')
        pseudo_message = ', '.join(pseudo_parts) or 'pseudo=off'
        print(
            f'round {round_index + 1:03d}/{args.rounds}: '
            f'teacher_acc={teacher_metrics["accuracy"]:.4f}, '
            f'student_acc={student_metrics["accuracy"]:.4f}, '
            f'f1={teacher_metrics["macro_f1"]:.4f}, {pseudo_message}')

    return model, teacher, tracker


def main():
    args = args_parser()
    args.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    seed_everything(args.seed)
    started_at = datetime.now()

    output_dir = args.output_dir or os.path.join(
        os.path.dirname(__file__), 'result', 'formal')
    os.makedirs(output_dir, exist_ok=True)
    timestamp = started_at.strftime('%Y%m%d_%H%M%S')
    run_stem = os.path.join(
        output_dir,
        f'{METHOD_NAME}-{args.dataset}'
        f'-rho{args.level_n_system:g}-eps{args.level_n_lowerb:g}'
        f'-u{args.unlabeled_ratio:g}-s{args.seed}-{timestamp}')
    log_path = f'{run_stem}.txt'
    scenario = prepare_scenario(args, log_path)

    model, teacher, tracker = run_training(args, scenario, log_path)
    elapsed = int((datetime.now() - started_at).total_seconds())
    summary = tracker.summary()
    write_log(f'summary: {summary}', log_path)
    print(f'completed in {elapsed}s; result={log_path}')
    del model, teacher
    torch.cuda.empty_cache()


if __name__ == '__main__':
    main()

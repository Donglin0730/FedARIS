import torch.nn.functional as F
from torch import nn


def conv3x3(in_channels, out_channels, stride=1):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=False,
    )


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.conv1 = conv3x3(in_channels, out_channels, stride)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = conv3x3(out_channels, out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)

        if stride == 1 and in_channels == out_channels:
            self.shortcut = nn.Identity()
        else:
            self.shortcut = nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=1,
                    stride=stride,
                    bias=False,
                ),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, inputs):
        residual = self.shortcut(inputs)
        outputs = F.relu(self.bn1(self.conv1(inputs)))
        outputs = self.bn2(self.conv2(outputs))
        return F.relu(outputs + residual)


class ResNet(nn.Module):
    """CIFAR ResNet with a shared feature interface for FedNS diagnostics."""

    def __init__(self, blocks_per_stage, num_classes):
        super().__init__()
        self.in_channels = 64
        self.conv1 = conv3x3(3, 64)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make_stage(64, blocks_per_stage[0], stride=1)
        self.layer2 = self._make_stage(128, blocks_per_stage[1], stride=2)
        self.layer3 = self._make_stage(256, blocks_per_stage[2], stride=2)
        self.layer4 = self._make_stage(512, blocks_per_stage[3], stride=2)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        # Keep the model feature name shared by the FedARIS architectures.
        self.linear = nn.Linear(512, num_classes)

    def _make_stage(self, out_channels, block_count, stride):
        strides = [stride] + [1] * (block_count - 1)
        blocks = []
        for block_stride in strides:
            blocks.append(BasicBlock(
                self.in_channels, out_channels, block_stride))
            self.in_channels = out_channels
        return nn.Sequential(*blocks)

    def forward_features(self, images):
        features = F.relu(self.bn1(self.conv1(images)))
        features = self.layer1(features)
        features = self.layer2(features)
        features = self.layer3(features)
        features = self.layer4(features)
        return self.avgpool(features).flatten(1)

    def forward_with_features(self, images):
        features = self.forward_features(images)
        return self.linear(features), features

    def forward(self, images, latent_output=False):
        logits, features = self.forward_with_features(images)
        return features if latent_output else logits


def ResNet18(num_classes=10):
    return ResNet([2, 2, 2, 2], num_classes)


def ResNet34(num_classes=100):
    return ResNet([3, 4, 6, 3], num_classes)

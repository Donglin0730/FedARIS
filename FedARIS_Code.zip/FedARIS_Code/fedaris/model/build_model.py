from model.model_resnet import ResNet18, ResNet34
from model.model_simple import FashionLeNet


MODEL_BUILDERS = {
    'fashionlenet': lambda num_classes: FashionLeNet(),
    'resnet18': ResNet18,
    'resnet34': ResNet34,
}


def build_model(args):
    """Build the backbone selected by the dataset loader."""
    try:
        builder = MODEL_BUILDERS[args.model]
    except KeyError as error:
        raise ValueError(f'Unsupported model: {args.model}') from error
    return builder(args.num_classes).to(args.device)

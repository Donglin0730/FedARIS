import torch.nn.functional as F
from torch import nn


class FashionLeNet(nn.Module):
    """LeNet backbone used by all Fashion-MNIST experiments."""

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 6, 5)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 4 * 4, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward_features(self, images):
        features = F.max_pool2d(F.relu(self.conv1(images)), 2)
        features = F.max_pool2d(F.relu(self.conv2(features)), 2)
        features = features.flatten(1)
        features = F.relu(self.fc1(features))
        return F.relu(self.fc2(features))

    def forward_with_features(self, images):
        features = self.forward_features(images)
        return self.fc3(features), features

    def forward(self, images, latent_output=False):
        logits, features = self.forward_with_features(images)
        return features if latent_output else logits

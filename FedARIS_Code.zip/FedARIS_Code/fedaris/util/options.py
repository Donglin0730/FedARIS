"""Fixed FedARIS paper protocol and command-line settings."""

import argparse
from dataclasses import dataclass


SCENARIO_PRESETS = {
    'clean': (0.0, 0.0, 0.0),
    'moderate': (0.4, 0.3, 0.3),
    'severe': (0.7, 0.5, 0.5),
    'noise-only': (0.4, 0.3, 0.0),
    'unlabeled-only': (0.0, 0.0, 0.5),
    'moderate-u50': (0.4, 0.3, 0.5),
}
SUPPORTED_DATASETS = ('fmnist', 'cifar10', 'cifar100', 'animal10')
@dataclass(frozen=True)
class FedARISConfig:
    """The single formal FedARIS configuration used by the paper."""

    # Client risk is a persistent, relative reliability signal.
    diagnostic_probe_size: int = 512
    client_probe_ratio: float = 0.2
    client_risk_ema: float = 0.9
    client_risk_enter: float = 0.7
    client_risk_exit: float = 0.4
    client_risk_streak: int = 2

    # Sample risk combines class-relative loss and stable teacher disagreement.
    sample_risk_ema: float = 0.9
    prediction_ema: float = 0.8
    risk_confidence: float = 0.6
    sample_risk_enter: float = 0.7
    sample_risk_exit: float = 0.4
    risk_enter_visits: int = 2
    risk_exit_visits: int = 2
    suspect_observed_weight_cap: float = 0.2
    risk_sample_override: float = 0.9
    robust_loss_q: float = 0.7

    # Risk recovery (R_i) and native unlabeled admission (U_i) stay separate.
    teacher_ema: float = 0.8
    risk_recovery_delay: int = 40
    unlabeled_recovery_delay: int = 40
    pseudo_rampup_rounds: int = 30
    risk_pseudo_weight: float = 0.05
    risk_pseudo_budget: int = 2
    unlabeled_pseudo_weight: float = 0.5
    risk_pseudo_threshold: float = 0.97
    unlabeled_pseudo_threshold: float = 0.95
    unlabeled_pseudo_threshold_floor: float = 0.90
    risk_pseudo_visits: int = 3
    unlabeled_pseudo_visits: int = 2
    risk_ready_min_samples: int = 16
    risk_ready_rounds: int = 3

    # Bounded teacher soft correction and reliability-aware aggregation.
    risk_soft_start_delay: int = 10
    risk_soft_max_alpha: float = 0.35
    risk_soft_high_recall_confidence: float = 0.65
    aggregation_strength: float = 1.0
    reliability_floor: float = 0.2
    refresh_interval: int = 20


def args_parser():
    parser = argparse.ArgumentParser(
        description='Train FedARIS with the paper protocol.')
    parser.add_argument('--rounds', type=int, default=200)
    parser.add_argument('--warmup_rounds', type=int, default=20)
    parser.add_argument('--local_ep', type=int, default=5)
    parser.add_argument('--frac', type=float, default=0.2)
    parser.add_argument('--num_users', type=int, default=50)
    parser.add_argument('--local_bs', type=int, default=10)
    parser.add_argument('--lr', type=float, default=0.03)
    parser.add_argument('--momentum', type=float, default=0.5)
    parser.add_argument('--dataset', choices=SUPPORTED_DATASETS, default='fmnist')
    parser.add_argument(
        '--scenario', choices=tuple(SCENARIO_PRESETS), default='moderate')
    parser.add_argument(
        '--partition', choices=('noniid', 'iid'), default='noniid')
    parser.add_argument('--non_iid_prob_class', type=float, default=0.7)
    parser.add_argument('--alpha_dirichlet', type=float, default=10.0)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--output_dir', default=None)
    args = parser.parse_args()
    _resolve_protocol(args)
    _validate(parser, args)
    return args


def _resolve_protocol(args):
    args.level_n_system, args.level_n_lowerb, args.unlabeled_ratio = (
        SCENARIO_PRESETS[args.scenario])
    args.iid = args.partition == 'iid'
    args.model = None
    args.num_classes = None
    defaults = (
        {'teacher_ema': 0.90, 'aggregation_strength': 0.50}
        if args.dataset == 'animal10'
        else {'teacher_ema': 0.80, 'aggregation_strength': 1.00}
    )
    args.fedns = FedARISConfig(**defaults)


def _validate(parser, args):
    if args.rounds < 1:
        parser.error('--rounds must be positive')
    if not 0 <= args.warmup_rounds < args.rounds:
        parser.error('--warmup_rounds must be in [0, rounds)')
    if args.num_users < 1 or not 0 < args.frac <= 1:
        parser.error('--num_users must be positive and --frac must be in (0, 1]')
    if args.local_ep < 1 or args.local_bs < 1:
        parser.error('--local_ep and --local_bs must be positive')
    if not 0 <= args.unlabeled_ratio < 1:
        parser.error('scenario unlabeled ratio must be in [0, 1)')
    if not 0 <= args.fedns.teacher_ema < 1:
        parser.error('teacher EMA must be in [0, 1)')
    if args.fedns.aggregation_strength < 0:
        parser.error('aggregation strength must be non-negative')

import copy
import numpy as np


def write_log(message, filename):
    with open(filename, 'a', encoding='utf-8') as file:
        file.write(message + '\n')


def add_noise(args, targets, labeled_users, filename):
    """Corrupt visible labels in L_i only; U_i is never passed here."""
    rng = np.random.RandomState(args.seed)
    noisy_client_mask = rng.binomial(
        1, args.level_n_system, args.num_users)
    client_noise = (
        args.level_n_lowerb
        + (1.0 - args.level_n_lowerb) * rng.rand(args.num_users)
    ) * noisy_client_mask

    noisy_targets = copy.deepcopy(targets)
    real_noise = np.zeros(args.num_users)
    for client_id in np.where(client_noise > 0)[0]:
        # Match the sample order used by every comparison method.
        indices = np.asarray(list(labeled_users[client_id]), dtype=np.int64)
        if not len(indices):
            continue
        positions = np.where(
            rng.rand(len(indices)) <= client_noise[client_id])[0]
        noisy_targets[indices[positions]] = rng.randint(
            0, args.num_classes, len(positions))
        ratio = np.mean(targets[indices] != noisy_targets[indices])
        real_noise[client_id] = ratio
        write_log(
            f'Client {client_id}, noise level: '
            f'{client_noise[client_id]:.4f}, '
            f'real labeled noise ratio: {ratio:.4f}',
            filename,
        )
    return noisy_targets, noisy_client_mask, real_noise


class NoReplacementClientSampler:
    """Visit every client once before starting the next shuffled cycle."""

    def __init__(self, num_clients, seed):
        self.num_clients = int(num_clients)
        self.rng = np.random.RandomState(int(seed))
        self.queue = np.empty(0, dtype=np.int64)

    def sample(self, count):
        count = min(max(int(count), 1), self.num_clients)
        chosen = []
        while len(chosen) < count:
            if not len(self.queue):
                self.queue = self.rng.permutation(self.num_clients)
            needed = count - len(chosen)
            take, keep = [], []
            for client_id in self.queue.tolist():
                if len(take) < needed and client_id not in chosen:
                    take.append(client_id)
                else:
                    keep.append(client_id)
            chosen.extend(take)
            self.queue = np.asarray(keep, dtype=np.int64)
        return np.asarray(chosen, dtype=np.int64)

def fixed_client_probes(labeled_users, maximum, seed):
    """Choose deterministic client probes for comparable loss trends."""
    probes = {}
    for client_id, values in labeled_users.items():
        indices = np.asarray(sorted(values), dtype=np.int64)
        if len(indices) > int(maximum):
            rng = np.random.RandomState(int(seed) + 7919 * int(client_id))
            indices = np.sort(rng.choice(
                indices, size=int(maximum), replace=False))
        probes[int(client_id)] = indices
    return probes


def iid_sampling(n_train, num_users, seed):
    """Assign every sample to exactly one IID client."""
    rng = np.random.RandomState(seed)
    splits = np.array_split(rng.permutation(n_train), num_users)
    return {
        client_id: set(indices.tolist())
        for client_id, indices in enumerate(splits)
    }


def non_iid_dirichlet_sampling(y_train, num_classes, p, num_users, seed,
                               alpha_dirichlet=100):
    rng = np.random.RandomState(seed)
    Phi = rng.binomial(1, p, size=(num_users, num_classes))
    n_classes_per_client = np.sum(Phi, axis=1)
    while np.min(n_classes_per_client) == 0:
        invalid_idx = np.where(n_classes_per_client==0)[0]
        Phi[invalid_idx] = rng.binomial(
            1, p, size=(len(invalid_idx), num_classes))
        n_classes_per_client = np.sum(Phi, axis=1)

    # A class must have at least one destination client.
    for class_id in np.where(Phi.sum(axis=0) == 0)[0]:
        Phi[rng.randint(0, num_users), class_id] = 1
    Psi = [list(np.where(Phi[:, j] == 1)[0]) for j in range(num_classes)]
    num_clients_per_class = np.array([len(x) for x in Psi])
    dict_users = {client_id: set() for client_id in range(num_users)}
    for class_i in range(num_classes):
        all_idxs = np.where(y_train==class_i)[0]
        p_dirichlet = rng.dirichlet(
            [alpha_dirichlet] * num_clients_per_class[class_i])
        assignment = rng.choice(
            Psi[class_i], size=len(all_idxs), p=p_dirichlet.tolist())

        for client_k in Psi[class_i]:
            dict_users[client_k].update(
                all_idxs[assignment == client_k].tolist())

    return dict_users


def split_labeled_unlabeled(dict_users, targets, unlabeled_ratio, seed,
                            min_labeled=1):
    """Stratify every client's data into noisy-labeled L_i and hidden U_i."""
    if not 0 <= unlabeled_ratio < 1:
        raise ValueError('unlabeled_ratio must be in [0, 1).')
    if min_labeled < 1:
        raise ValueError('min_labeled must be at least 1.')

    targets = np.asarray(targets).reshape(-1)
    rng = np.random.RandomState(seed)
    labeled_users, unlabeled_users = {}, {}
    for client_id in sorted(dict_users):
        client_indices = np.asarray(
            sorted(dict_users[client_id]), dtype=np.int64)
        unlabeled_count = min(
            int(round(len(client_indices) * unlabeled_ratio)),
            max(len(client_indices) - min_labeled, 0),
        )
        if unlabeled_count == 0:
            unlabeled_indices = np.empty(0, dtype=np.int64)
        else:
            unlabeled_indices = _stratified_unlabeled_indices(
                client_indices, targets, unlabeled_count, rng)

        unlabeled = set(unlabeled_indices.tolist())
        labeled = set(client_indices.tolist()) - unlabeled
        if labeled & unlabeled or labeled | unlabeled != set(client_indices):
            raise RuntimeError(
                f'Invalid labeled/unlabeled split for client {client_id}.')
        labeled_users[client_id] = labeled
        unlabeled_users[client_id] = unlabeled
    return labeled_users, unlabeled_users


def _stratified_unlabeled_indices(client_indices, targets,
                                  unlabeled_count, rng):
    """Preserve each client's class proportions as closely as possible."""
    client_targets = targets[client_indices]
    classes, counts = np.unique(client_targets, return_counts=True)
    ideal = unlabeled_count * counts / counts.sum()
    quotas = np.floor(ideal).astype(int)

    # Keep one labeled example per local class whenever the ratio permits.
    preferred_capacity = np.maximum(counts - 1, 0)
    quotas = np.minimum(quotas, preferred_capacity)
    remaining = unlabeled_count - int(quotas.sum())
    order = np.argsort(-(ideal - np.floor(ideal)))
    for capacity in (preferred_capacity, counts):
        while remaining > 0:
            progressed = False
            for class_pos in order:
                if quotas[class_pos] < capacity[class_pos]:
                    quotas[class_pos] += 1
                    remaining -= 1
                    progressed = True
                    if remaining == 0:
                        break
            if not progressed:
                break
    if remaining:
        raise RuntimeError('Unable to satisfy the requested unlabeled ratio.')

    selected = []
    for class_id, quota in zip(classes, quotas):
        class_indices = client_indices[client_targets == class_id]
        if quota:
            selected.extend(rng.choice(
                class_indices, size=quota, replace=False).tolist())
    return np.asarray(selected, dtype=np.int64)



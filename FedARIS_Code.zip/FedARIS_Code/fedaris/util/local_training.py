"""Local objectives for the three FedARIS supervision sources.

Observed labels, corrected risky labels (R_i), and native unlabeled examples
(U_i) are optimized together but keep independent coefficients and acceptance
plans.  Losses are normalized by their effective supervision mass so adding a
source does not implicitly change the local learning-rate scale.
"""

import copy

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset


class WeightedLabeledDataset(Dataset):
    """Expose labels, reliability weights, and optional soft targets."""

    def __init__(self, dataset, indices, weights, soft_targets, soft_alpha):
        self.dataset = dataset
        self.indices = np.asarray(indices, dtype=np.int64)
        self.weights = np.asarray(weights, dtype=np.float32)
        self.soft_targets = np.asarray(soft_targets, dtype=np.float32)
        self.soft_alpha = np.asarray(soft_alpha, dtype=np.float32)
        if (self.indices.shape != self.weights.shape
                or self.soft_alpha.shape != self.weights.shape
                or self.soft_targets.shape[0] != len(self.indices)):
            raise ValueError('Labeled supervision arrays must align.')

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, position):
        image, label = self.dataset[int(self.indices[position])]
        return (
            image,
            int(label),
            float(self.weights[position]),
            self.soft_targets[position],
            float(self.soft_alpha[position]),
        )


class PseudoTargetDataset(Dataset):
    """Expose only pseudo labels accepted before local optimization."""

    def __init__(self, dataset, indices, targets, weights):
        self.dataset = dataset
        self.indices = np.asarray(indices, dtype=np.int64)
        self.targets = np.asarray(targets, dtype=np.int64)
        self.weights = np.asarray(weights, dtype=np.float32)
        if not (self.indices.shape == self.targets.shape == self.weights.shape):
            raise ValueError('Pseudo indices, targets, and weights must align.')

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, position):
        image, _ = self.dataset[int(self.indices[position])]
        return (
            image,
            int(self.targets[position]),
            float(self.weights[position]),
        )


def weak_augment(images, padding=1, probability=0.5):
    """Apply random zero-padded translation without changing tensor shape."""
    if images.ndim != 4:
        return images
    padding = int(padding)
    padded = F.pad(images, (padding, padding, padding, padding), value=0.0)
    height, width = images.shape[-2:]
    translated = torch.empty_like(images)
    for position in range(len(images)):
        if float(torch.rand(1).item()) >= float(probability):
            translated[position] = images[position]
            continue
        top = int(torch.randint(0, 2 * padding + 1, (1,)).item())
        left = int(torch.randint(0, 2 * padding + 1, (1,)).item())
        translated[position] = padded[
            position, :, top:top + height, left:left + width]
    return translated


def strong_augment(images):
    """Build the strong FixMatch view without consulting hidden labels."""
    augmented = weak_augment(images, padding=2, probability=1.0)
    if augmented.ndim != 4:
        return augmented + 0.01 * torch.randn_like(augmented)

    height, width = augmented.shape[-2:]
    cutout = max(min(height, width) // 6, 1)
    for position in range(len(augmented)):
        top = int(torch.randint(
            0, max(height - cutout + 1, 1), (1,)).item())
        left = int(torch.randint(
            0, max(width - cutout + 1, 1), (1,)).item())
        augmented[position, :, top:top + cutout, left:left + cutout] = 0.0
    return augmented


def generalized_cross_entropy(logits, targets, q=0.7):
    """Return bounded per-sample GCE for robust observed-label training."""
    q = float(q)
    if q <= 0.0:
        raise ValueError('GCE q must be positive.')
    probabilities = F.softmax(logits, dim=1)
    target_probability = probabilities.gather(
        1, targets.view(-1, 1)).squeeze(1).clamp_min(1e-8)
    return (1.0 - target_probability.pow(q)) / q


class FedNSLocalUpdate:
    """Optimize observed labels and separate R_i/U_i pseudo targets."""

    def __init__(self, args, dataset, labeled_indices, observed_weights,
                 pseudo_plans=None, augmentation_enabled=False,
                 supervised_robustness=0.0, robust_loss_q=0.7,
                 soft_targets=None, soft_alpha=None):
        self.args = args
        self.augmentation_enabled = bool(augmentation_enabled)
        self.supervised_robustness = float(np.clip(
            supervised_robustness, 0.0, 1.0))
        self.robust_loss_q = float(robust_loss_q)
        labeled_indices = np.asarray(labeled_indices, dtype=np.int64)
        observed_weights = np.asarray(observed_weights, dtype=np.float32)
        if soft_targets is None:
            labels = np.asarray([
                int(dataset[int(index)][1]) for index in labeled_indices
            ], dtype=np.int64)
            soft_targets = np.eye(
                int(args.num_classes), dtype=np.float32)[labels]
        if soft_alpha is None:
            soft_alpha = np.zeros(len(labeled_indices), dtype=np.float32)
        labeled_dataset = WeightedLabeledDataset(
            dataset, labeled_indices, observed_weights,
            soft_targets, soft_alpha)
        if not len(labeled_dataset):
            raise ValueError('FedARIS requires at least one labeled sample/client.')
        self.labeled_loader = DataLoader(
            labeled_dataset,
            batch_size=args.local_bs,
            shuffle=True,
            drop_last=False,
        )

        # Plans are frozen by the server-side EMA teacher before SGD starts.
        self.pseudo_loaders = {}
        self.accepted_masses = {}
        for source, plan in dict(pseudo_plans or {}).items():
            accepted = np.asarray(plan['accepted'], dtype=bool)
            indices = np.asarray(plan['indices'], dtype=np.int64)[accepted]
            targets = np.asarray(plan['targets'], dtype=np.int64)[accepted]
            weights = np.asarray(
                plan.get('weights', np.ones(len(accepted))),
                dtype=np.float32,
            )[accepted]
            pseudo_dataset = PseudoTargetDataset(
                dataset, indices, targets, weights)
            self.accepted_masses[source] = float(weights.sum())
            if len(pseudo_dataset):
                self.pseudo_loaders[source] = DataLoader(
                    pseudo_dataset,
                    batch_size=args.local_bs,
                    shuffle=True,
                    drop_last=False,
                )

    @staticmethod
    def _next_batch(iterator):
        if iterator is None:
            return None
        try:
            return next(iterator)
        except StopIteration:
            # Consume each accepted pseudo sample at most once per local epoch.
            return None

    def update_weights(self, model, source_weights):
        """Use one effective-mass definition for loss and aggregation."""
        model.train()
        optimizer = torch.optim.SGD(
            model.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        losses = []

        for _ in range(int(self.args.local_ep)):
            iterators = {
                source: iter(loader)
                for source, loader in self.pseudo_loaders.items()
            }
            for images, labels, weights, soft_targets, soft_alpha \
                    in self.labeled_loader:
                images = images.to(self.args.device)
                if self.augmentation_enabled:
                    images = weak_augment(images)
                labels = labels.to(self.args.device).long()
                weights = weights.to(self.args.device).float()
                soft_targets = soft_targets.to(self.args.device).float()
                soft_alpha = soft_alpha.to(self.args.device).float()
                optimizer.zero_grad(set_to_none=True)

                logits = model(images)
                supervised = F.cross_entropy(
                    logits, labels, reduction='none')
                if self.supervised_robustness > 0.0:
                    robust = generalized_cross_entropy(
                        logits, labels, self.robust_loss_q)
                    supervised = (
                        (1.0 - self.supervised_robustness) * supervised
                        + self.supervised_robustness * robust)
                if torch.any(soft_alpha > 0.0):
                    soft_loss = -(
                        soft_targets * F.log_softmax(logits, dim=1)
                    ).sum(dim=1)
                    supervised = (
                        (1.0 - soft_alpha) * supervised
                        + soft_alpha * soft_loss)
                loss_sum = (supervised * weights).sum()
                batch_mass = weights.sum()

                # Normalize observed and pseudo losses together so enabling a
                # source does not silently change the local step magnitude.
                for source, iterator in iterators.items():
                    coefficient = float(source_weights.get(source, 0.0))
                    if coefficient <= 0.0:
                        continue
                    batch = self._next_batch(iterator)
                    if batch is None:
                        continue
                    pseudo_images, pseudo_targets, pseudo_weights = batch
                    pseudo_images = strong_augment(
                        pseudo_images.to(self.args.device))
                    pseudo_targets = pseudo_targets.to(
                        self.args.device).long()
                    pseudo_weights = pseudo_weights.to(
                        self.args.device).float()
                    pseudo_loss = F.cross_entropy(
                        model(pseudo_images), pseudo_targets, reduction='none')
                    loss_sum += coefficient * (
                        pseudo_loss * pseudo_weights).sum()
                    batch_mass += coefficient * pseudo_weights.sum()

                total_loss = loss_sum / batch_mass.clamp_min(1e-8)
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    model.parameters(), max_norm=10.0)
                optimizer.step()
                losses.append(float(total_loss.item()))

        labeled_mass = float(
            self.labeled_loader.dataset.weights.astype(np.float64).sum())
        pseudo_mass = sum(
            float(source_weights.get(source, 0.0)) * mass
            for source, mass in self.accepted_masses.items()
        )
        return {
            'weights': copy.deepcopy(model.state_dict()),
            'loss': float(np.mean(losses)) if losses else 0.0,
            'effective_mass': labeled_mass + float(pseudo_mass),
            'labeled_mass': labeled_mass,
            'pseudo_mass': float(pseudo_mass),
        }

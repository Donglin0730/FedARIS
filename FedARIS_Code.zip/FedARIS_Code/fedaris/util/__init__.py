"""FedARIS data, training, diagnostics, and state utilities."""

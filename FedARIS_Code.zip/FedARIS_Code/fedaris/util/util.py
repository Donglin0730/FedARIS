"""Core FedARIS risk estimation and supervision-coordination utilities.

Client risk is a cross-client prior derived from robust loss statistics.
Sample risk combines persistent relative loss with stable teacher-label
contradiction.  The two signals are not treated as calibrated noise
probabilities; they gate and weight conservative training decisions.
"""

import copy

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.mixture import GaussianMixture
from torch.utils.data import DataLoader, Subset


def _method_config(args):
    """Accept production arguments and lightweight unit-test fixtures."""
    return getattr(args, 'fedns', args)


def make_ema_teacher(student):
    """Create the frozen teacher used for diagnostics and pseudo labels."""
    teacher = copy.deepcopy(student)
    teacher.eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    return teacher


@torch.no_grad()
def update_ema_teacher(teacher, student, decay):
    """EMA-update floating tensors and copy integer model buffers."""
    for teacher_value, student_value in zip(
            teacher.state_dict().values(), student.state_dict().values()):
        if teacher_value.is_floating_point():
            teacher_value.mul_(decay).add_(
                student_value.detach(), alpha=1.0 - decay)
        else:
            teacher_value.copy_(student_value.detach())
    teacher.eval()


# A labeled sample moves between TRUSTED and SUSPECT as evidence changes.
# RECOVERED means that a contradictory R_i pseudo target was accepted during
# its most recent visit; the original label is still stored and can recover.
TRUSTED = 0
SUSPECT = 1
RECOVERED = 2
UNLABELED = 3


def _js_similarity(first, second):
    """Return bounded prediction similarity for temporal risk evidence."""
    first = np.clip(np.asarray(first, dtype=np.float64), 1e-12, 1.0)
    second = np.clip(np.asarray(second, dtype=np.float64), 1e-12, 1.0)
    first /= first.sum(axis=1, keepdims=True)
    second /= second.sum(axis=1, keepdims=True)
    midpoint = 0.5 * (first + second)
    divergence = 0.5 * np.sum(first * np.log(first / midpoint), axis=1)
    divergence += 0.5 * np.sum(
        second * np.log(second / midpoint), axis=1)
    return np.clip(1.0 - divergence / np.log(2.0), 0.0, 1.0)


def _robust_unit(values, valid):
    """Map cross-client losses to [0, 1] using median and MAD."""
    values = np.asarray(values, dtype=np.float64)
    valid = np.asarray(valid, dtype=bool)
    result = np.full(len(values), 0.5, dtype=np.float64)
    selected = values[valid]
    if not len(selected):
        return result
    center = float(np.median(selected))
    mad = float(np.median(np.abs(selected - center)))
    if mad < 1e-12:
        return result
    z_score = np.clip((selected - center) / (1.4826 * mad), -20.0, 20.0)
    result[valid] = 1.0 / (1.0 + np.exp(-z_score))
    return result


def _gmm_client_risk(values, valid, minimum_bic_gain=10.0):
    """Estimate a majority-safe client partition from observable losses.

    BIC must strongly prefer two Gaussian components over one. This permits a
    high-loss majority without assuming its size, while falling back when the
    loss distribution does not provide enough evidence for a partition.
    """
    values = np.asarray(values, dtype=np.float64)
    valid = np.asarray(valid, dtype=bool) & np.isfinite(values)
    probabilities = np.full(len(values), 0.5, dtype=np.float64)
    selected = values[valid]
    required = max(6, int(np.ceil(0.8 * len(values))))
    if len(selected) < required or np.ptp(selected) < 1e-6:
        return probabilities, False, 0.0, np.zeros(2, dtype=np.float64)

    samples = selected.reshape(-1, 1)
    one = GaussianMixture(
        n_components=1, covariance_type='full', reg_covar=1e-4,
        n_init=1, random_state=0).fit(samples)
    two = GaussianMixture(
        n_components=2, covariance_type='full', reg_covar=1e-4,
        n_init=5, random_state=0).fit(samples)
    bic_gain = float(one.bic(samples) - two.bic(samples))
    means = two.means_.reshape(-1)
    high_component = int(np.argmax(means))
    assignments = two.predict(samples)
    component_sizes = np.bincount(assignments, minlength=2)
    minimum_group = max(3, int(np.ceil(0.1 * len(selected))))
    accepted = (
        bic_gain >= float(minimum_bic_gain)
        and int(component_sizes.min()) >= minimum_group
    )
    if accepted:
        probabilities[valid] = two.predict_proba(samples)[:, high_component]
    return probabilities, bool(accepted), bic_gain, np.sort(means)


def _rank(values):
    """Return average percentile ranks while assigning ties the same rank."""
    values = np.asarray(values, dtype=np.float64)
    if len(values) <= 1:
        return np.full(len(values), 0.5, dtype=np.float64)
    unique, inverse, counts = np.unique(
        values, return_inverse=True, return_counts=True)
    del unique
    lower = np.cumsum(counts) - counts
    middle = lower + 0.5 * (counts - 1)
    return middle[inverse] / float(len(values) - 1)


def _loss_outlier_evidence(losses, labels, minimum_group=5):
    """Score persistent high loss relative to the same observed class.

    Ranking alone would always flag one sample, even when all losses are
    nearly equal. The robust magnitude term requires a meaningful loss gap;
    the rank term then limits evidence to the upper half of the group.
    """
    losses = np.asarray(losses, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    if losses.shape != labels.shape:
        raise ValueError('Losses and labels must align for risk evidence.')

    result = np.zeros(len(losses), dtype=np.float64)

    def score(positions):
        values = losses[positions]
        center = float(np.median(values))
        mad = float(np.median(np.abs(values - center)))
        scale = max(1.4826 * mad, 0.1 * abs(center), 1e-3)
        positive_z = np.maximum((values - center) / scale, 0.0)
        magnitude = 1.0 - np.exp(-positive_z / 2.0)
        upper_rank = np.clip(2.0 * (_rank(values) - 0.5), 0.0, 1.0)
        result[positions] = magnitude * upper_rank

    all_positions = np.arange(len(losses), dtype=np.int64)
    score(all_positions)
    for label in np.unique(labels):
        positions = np.where(labels == label)[0]
        if len(positions) >= int(minimum_group):
            score(positions)
    return np.clip(result, 0.0, 1.0)


def reliability_aggregation_masses(
        effective_masses, client_risks, strength=0.5, floor=0.2):
    """Combine usable supervision mass with a bounded client-risk discount."""
    """Apply reliability once to the same mass used by the local loss."""
    masses = np.asarray(effective_masses, dtype=np.float64)
    risks = np.asarray(client_risks, dtype=np.float64)
    if masses.ndim != 1 or risks.ndim != 1 or masses.size != risks.size:
        raise ValueError('Effective masses and client risks must be aligned.')
    if not masses.size or np.any(~np.isfinite(masses)) or np.any(masses < 0):
        raise ValueError('Effective masses must be finite and non-negative.')
    if np.any(~np.isfinite(risks)):
        raise ValueError('Client risks must be finite.')
    if not 0 <= float(strength) <= 1 or not 0 <= float(floor) <= 1:
        raise ValueError('Aggregation strength and floor must be in [0, 1].')

    reliability = np.clip(
        1.0 - float(strength) * np.clip(risks, 0.0, 1.0),
        float(floor),
        1.0,
    )
    weighted = masses * reliability
    if weighted.sum() <= 0:
        raise ValueError('Reliability aggregation requires positive mass.')
    return weighted.tolist()


def unlabeled_recovery_start_round(args):
    """Return the first zero-based round allowed to use U_i."""
    return int(args.warmup_rounds) + int(
        args.fedns.unlabeled_recovery_delay)


def pseudo_coefficients(args, round_index, risk_start_round=None):
    """Use a small fixed R_i weight and ramp the reusable U_i source."""
    config = args.fedns

    def ramp(start_round):
        if start_round is None:
            return 0.0
        active_round = int(round_index) - int(start_round)
        return 0.0 if active_round < 0 else min(
            (active_round + 1) / float(config.pseudo_rampup_rounds), 1.0)

    return {
        'risk': (
            float(config.risk_pseudo_weight)
            if (risk_start_round is not None
                and int(round_index) >= int(risk_start_round)) else 0.0),
        'unlabeled': (
            float(config.unlabeled_pseudo_weight) * ramp(
                unlabeled_recovery_start_round(args))),
    }


@torch.no_grad()
def collect_fedns_observation(model, dataset, indices, args,
                              observed_targets=None):
    """Collect teacher probabilities and observed-label losses."""
    indices = np.asarray(sorted(int(index) for index in indices), dtype=np.int64)
    if not len(indices):
        return {
            'indices': indices,
            'labels': np.empty(0, dtype=np.int64),
            'probabilities': np.empty((0, args.num_classes)),
            'losses': np.empty(0),
            'mean_loss': 0.0,
        }
    loader = DataLoader(
        Subset(dataset, indices.tolist()), batch_size=100, shuffle=False,
        drop_last=False, num_workers=0)
    target_array = None
    if observed_targets is not None:
        target_array = np.asarray(observed_targets, dtype=np.int64)[indices]

    probabilities, losses, labels = [], [], []
    offset = 0
    model.eval()
    for images, batch_labels in loader:
        images = images.to(args.device)
        if target_array is None:
            batch_labels = batch_labels.to(args.device).view(-1).long()
        else:
            size = len(batch_labels)
            batch_labels = torch.as_tensor(
                target_array[offset:offset + size],
                device=args.device,
                dtype=torch.long,
            )
            offset += size
        logits = model(images)
        probabilities.append(F.softmax(logits, dim=1).cpu().numpy())
        losses.append(F.cross_entropy(
            logits, batch_labels, reduction='none').cpu().numpy())
        labels.append(batch_labels.cpu().numpy())

    labels = np.concatenate(labels)
    if np.any(labels < 0):
        raise RuntimeError('A FedARIS diagnostic received a hidden U_i target.')
    losses = np.concatenate(losses)
    return {
        'indices': indices,
        'labels': labels,
        'probabilities': np.concatenate(probabilities),
        'losses': losses,
        'mean_loss': float(np.median(losses)),
    }


@torch.no_grad()
def collect_teacher_prediction(model, dataset, indices, args):
    """Predict image-only data without reading a hidden target into training."""
    indices = np.asarray(sorted(int(index) for index in indices), dtype=np.int64)
    if not len(indices):
        return {
            'indices': indices,
            'probabilities': np.empty((0, args.num_classes)),
        }
    model.eval()
    probabilities = []
    for start in range(0, len(indices), 100):
        batch_indices = indices[start:start + 100]
        # Dataset targets are discarded at access and never enter a plan.
        images = torch.stack([dataset[int(index)][0] for index in batch_indices])
        logits = model(images.to(args.device))
        probabilities.append(F.softmax(logits, dim=1).cpu().numpy())
    return {
        'indices': indices,
        'probabilities': np.concatenate(probabilities),
    }


class FedNSState:
    """Visit-based memory for client risk, sample risk, and recovery."""

    def __init__(self, args, num_samples):
        self.config = _method_config(args)
        self.num_clients = int(args.num_users)
        self.num_samples = int(num_samples)
        self.num_classes = int(args.num_classes)

        self.client_loss_history = [[] for _ in range(self.num_clients)]
        self.client_risk = np.zeros(self.num_clients, dtype=np.float64)
        self.client_high_risk = np.zeros(self.num_clients, dtype=bool)
        self.client_enter_streak = np.zeros(self.num_clients, dtype=np.int64)
        self.client_exit_streak = np.zeros(self.num_clients, dtype=np.int64)
        self.probe_cursor = np.zeros(self.num_clients, dtype=np.int64)
        self.client_group_risk = np.full(
            self.num_clients, 0.5, dtype=np.float64)
        self.client_gmm_means = np.zeros(2, dtype=np.float64)
        self.client_gmm_bic_gain = 0.0
        self.client_risk_threshold = float(self.config.client_risk_enter)
        self.client_threshold_is_adaptive = False

        self.sample_state = np.full(self.num_samples, TRUSTED, dtype=np.int8)
        self.sample_risk = np.zeros(self.num_samples, dtype=np.float64)
        self.sample_loss_risk = np.zeros(
            self.num_samples, dtype=np.float64)
        self.sample_visits = np.zeros(self.num_samples, dtype=np.int64)
        self.sample_probabilities = np.zeros(
            (self.num_samples, self.num_classes), dtype=np.float32)
        self.sample_enter_streak = np.zeros(self.num_samples, dtype=np.int64)
        self.sample_exit_streak = np.zeros(self.num_samples, dtype=np.int64)

        # R_i and U_i are disjoint, so one prediction-streak array is enough.
        self.pseudo_prediction = np.full(
            self.num_samples, -1, dtype=np.int64)
        self.pseudo_streak = np.zeros(self.num_samples, dtype=np.int64)
        self.risk_pseudo_uses = np.zeros(self.num_samples, dtype=np.int16)
        self.soft_correction_uses = np.zeros(
            self.num_samples, dtype=np.int16)
        # Counts are committed once after a round. Every client in that round
        # therefore uses the same thresholds derived from earlier evidence.
        self.unlabeled_class_accepts = np.zeros(
            self.num_classes, dtype=np.int64)
        self.risk_readiness_streak = 0
        self.risk_start_round = None

    @property
    def client_risk_initialized(self):
        return np.asarray([
            len(history) >= 3 for history in self.client_loss_history
        ], dtype=bool)

    @property
    def sample_risk_initialized(self):
        return self.sample_visits >= 2

    def initialize_sources(self, labeled_users, unlabeled_users):
        assigned = np.zeros(self.num_samples, dtype=bool)
        for indices in labeled_users.values():
            indices = np.asarray(sorted(indices), dtype=np.int64)
            self.sample_state[indices] = TRUSTED
            assigned[indices] = True
        for indices in unlabeled_users.values():
            indices = np.asarray(sorted(indices), dtype=np.int64)
            self.sample_state[indices] = UNLABELED
            assigned[indices] = True
        if not assigned.all():
            raise ValueError('Every training sample must belong to L_i or U_i.')

    def observe_client(self, client_id, mean_loss):
        self.client_loss_history[int(client_id)].append(float(mean_loss))

    def refresh_client_risks(self, touched_clients):
        """Estimate client risk from robustly normalized median loss only."""
        visits = np.asarray(
            [len(history) for history in self.client_loss_history],
            dtype=np.int64)
        valid = visits > 0
        median_loss = np.zeros(self.num_clients, dtype=np.float64)
        for client_id in np.where(valid)[0]:
            median_loss[client_id] = np.median(
                self.client_loss_history[client_id])
        raw_risk = _robust_unit(median_loss, valid)

        touched_clients = np.asarray(touched_clients, dtype=np.int64)
        for client_id in touched_clients:
            # Three visits prevent the first random probe from fixing a client
            # state before cross-client losses become meaningful.
            if visits[client_id] < 3:
                continue
            if visits[client_id] > 3:
                self.client_risk[client_id] = (
                    self.config.client_risk_ema * self.client_risk[client_id]
                    + (1.0 - self.config.client_risk_ema)
                    * raw_risk[client_id])
            else:
                self.client_risk[client_id] = raw_risk[client_id]

        group_risk, is_adaptive, bic_gain, means = _gmm_client_risk(
            median_loss,
            self.client_risk_initialized,
        )
        self.client_group_risk = group_risk
        self.client_gmm_bic_gain = float(bic_gain)
        self.client_gmm_means = np.asarray(means, dtype=np.float64)
        threshold = (
            0.5 if is_adaptive else float(self.config.client_risk_enter))
        decision_risk = group_risk if is_adaptive else self.client_risk
        self.client_risk_threshold = float(threshold)
        self.client_threshold_is_adaptive = is_adaptive
        exit_threshold = (
            threshold if is_adaptive else float(self.config.client_risk_exit))

        for client_id in touched_clients:
            if not self.client_risk_initialized[client_id]:
                continue
            above = decision_risk[client_id] >= threshold
            below = decision_risk[client_id] < exit_threshold
            self.client_enter_streak[client_id] = (
                self.client_enter_streak[client_id] + 1 if above else 0)
            self.client_exit_streak[client_id] = (
                self.client_exit_streak[client_id] + 1 if below else 0)
            if self.client_enter_streak[client_id] >= int(
                    self.config.client_risk_streak):
                self.client_high_risk[client_id] = True
            if self.client_exit_streak[client_id] >= int(
                    self.config.client_risk_streak):
                self.client_high_risk[client_id] = False
        return raw_risk

    def sample_enter_threshold(self, client_id=None):
        """Lower the suspect gate only inside a confirmed risky client."""
        default = float(self.config.sample_risk_enter)
        # The formal gate raises recall while the observed-label cap keeps
        # uncertain samples from replacing their labels.
        default = max(
            float(self.config.sample_risk_exit) + 0.1,
            default - 0.15,
        )
        if (client_id is None or not self.client_threshold_is_adaptive
                or not self.client_high_risk[int(client_id)]):
            return default

        floor = 0.5 * (
            default + float(self.config.sample_risk_exit))
        boundary = 0.5
        severity = np.clip(
            (self.client_group_risk[int(client_id)] - boundary)
            / max(1.0 - boundary, 1e-12),
            0.0,
            1.0,
        )
        # Increase recall continuously as the client's GMM risk rises.
        progress = 0.5 + 0.5 * severity
        return float(default - progress * (default - floor))

    def diagnostic_indices(self, client_id, labeled_indices):
        """Fully inspect high-risk clients and rotate a probe on the rest."""
        indices = np.asarray(sorted(labeled_indices), dtype=np.int64)
        if not len(indices) or self.client_high_risk[int(client_id)]:
            return indices
        count = max(int(np.ceil(
            len(indices) * float(self.config.client_probe_ratio))), 1)
        cursor = int(self.probe_cursor[int(client_id)]) % len(indices)
        positions = (np.arange(count) + cursor) % len(indices)
        self.probe_cursor[int(client_id)] = (cursor + count) % len(indices)
        return indices[positions]

    def observe_labeled(self, observation, client_id=None):
        """Update sample risk from persistent loss and teacher contradiction."""
        indices = np.asarray(observation['indices'], dtype=np.int64)
        if not len(indices):
            return
        probabilities = np.asarray(
            observation['probabilities'], dtype=np.float64)
        labels = np.asarray(observation['labels'], dtype=np.int64)
        losses = np.asarray(observation['losses'], dtype=np.float64)
        previous_seen = self.sample_visits[indices] > 0
        previously_initialized = self.sample_visits[indices] >= 2
        previous = self.sample_probabilities[indices].astype(np.float64)

        confidence = probabilities.max(axis=1)
        predicted = probabilities.argmax(axis=1)
        contradiction = 1.0 - probabilities[np.arange(len(labels)), labels]
        confidence_evidence = np.where(
            confidence >= self.config.risk_confidence, confidence, 0.0)
        temporal = np.zeros(len(indices), dtype=np.float64)
        if previous_seen.any():
            temporal[previous_seen] = _js_similarity(
                probabilities[previous_seen], previous[previous_seen])
        contradiction_evidence = (
            (predicted != labels).astype(np.float64)
            * np.cbrt(np.maximum(
                confidence_evidence * contradiction * temporal, 0.0)))
        current_loss_risk = _loss_outlier_evidence(losses, labels)

        # Loss history catches mislabeled samples before the teacher memorizes
        # their visible labels. Teacher contradiction remains the precise path
        # when a stable alternative class is already available.
        self.sample_loss_risk[indices] = np.where(
            previous_seen,
            self.config.sample_risk_ema * self.sample_loss_risk[indices]
            + (1.0 - self.config.sample_risk_ema) * current_loss_risk,
            current_loss_risk,
        )
        evidence = np.maximum(
            contradiction_evidence, self.sample_loss_risk[indices])

        enter_threshold = self.sample_enter_threshold(client_id)
        for position, sample_index in enumerate(indices):
            if previous_seen[position]:
                if previously_initialized[position]:
                    self.sample_risk[sample_index] = (
                        self.config.sample_risk_ema
                        * self.sample_risk[sample_index]
                        + (1.0 - self.config.sample_risk_ema)
                        * evidence[position])
                else:
                    self.sample_risk[sample_index] = evidence[position]

            risk = self.sample_risk[sample_index]
            above = previous_seen[position] and (
                risk >= enter_threshold)
            below = previous_seen[position] and (
                risk <= self.config.sample_risk_exit)
            self.sample_enter_streak[sample_index] = (
                self.sample_enter_streak[sample_index] + 1 if above else 0)
            self.sample_exit_streak[sample_index] = (
                self.sample_exit_streak[sample_index] + 1 if below else 0)
            if self.sample_enter_streak[sample_index] >= int(
                    self.config.risk_enter_visits):
                self.sample_state[sample_index] = SUSPECT
            if self.sample_exit_streak[sample_index] >= int(
                    self.config.risk_exit_visits):
                self.sample_state[sample_index] = TRUSTED

        updated = probabilities.copy()
        if previous_seen.any():
            updated[previous_seen] = (
                self.config.prediction_ema * previous[previous_seen]
                + (1.0 - self.config.prediction_ema)
                * probabilities[previous_seen])
            updated[previous_seen] /= np.maximum(
                updated[previous_seen].sum(axis=1, keepdims=True), 1e-12)
        self.sample_probabilities[indices] = updated.astype(np.float32)
        self.sample_visits[indices] += 1

    def observed_weights(self, indices):
        """Downgrade risk continuously and cap unresolved SUSPECT labels."""
        indices = np.asarray(indices, dtype=np.int64)
        weights = np.ones(len(indices), dtype=np.float32)
        initialized = self.sample_visits[indices] >= 2
        weights[initialized] = np.clip(
            1.0 - self.sample_risk[indices[initialized]], 0.0, 1.0)
        # Accepting a contradictory pseudo target does not make the original
        # observed label trustworthy again. Keep both SUSPECT and RECOVERED
        # labels capped until the reversible state machine returns to TRUSTED.
        downgraded = np.isin(
            self.sample_state[indices], [SUSPECT, RECOVERED])
        weights[downgraded] = np.minimum(
            weights[downgraded],
            float(self.config.suspect_observed_weight_cap),
        )
        return weights

    def risk_indices(self, labeled_indices):
        indices = np.asarray(sorted(labeled_indices), dtype=np.int64)
        mask = np.isin(self.sample_state[indices], [SUSPECT, RECOVERED])
        return indices[mask]

    def unlabeled_class_thresholds(self):
        """Use prior-round accepted counts for class-wise self-paced gates."""
        ceiling = float(self.config.unlabeled_pseudo_threshold)
        floor = float(self.config.unlabeled_pseudo_threshold_floor)
        maximum = int(self.unlabeled_class_accepts.max())
        if maximum <= 0:
            return np.full(self.num_classes, ceiling, dtype=np.float64)
        relative_acceptance = (
            self.unlabeled_class_accepts.astype(np.float64) / maximum)
        return ceiling - (ceiling - floor) * relative_acceptance

    def commit_unlabeled_round(self, plans):
        """Commit accepted unlabeled counts once after the frozen round plan."""
        round_counts = np.zeros(self.num_classes, dtype=np.int64)
        for plan in plans:
            if plan['source'] != 'unlabeled':
                continue
            targets = np.asarray(plan['targets'], dtype=np.int64)
            accepted = np.asarray(plan['accepted'], dtype=bool)
            round_counts += np.bincount(
                targets[accepted], minlength=self.num_classes)
        self.unlabeled_class_accepts += round_counts
        return round_counts

    def build_pseudo_plan(
            self, observation, source, observed_targets=None,
            client_is_high_risk=False, commit=True):
        """Apply source-specific confidence and consistency gates."""
        indices = np.asarray(observation['indices'], dtype=np.int64)
        probabilities = np.asarray(
            observation['probabilities'], dtype=np.float64)
        targets = probabilities.argmax(axis=1)
        confidence = probabilities.max(axis=1)
        is_risk = source == 'risk'
        if source not in {'risk', 'unlabeled'}:
            raise ValueError(f'Unknown pseudo source: {source}')
        if is_risk:
            thresholds = np.full(
                len(indices), float(self.config.risk_pseudo_threshold))
        else:
            thresholds = self.unlabeled_class_thresholds()[targets]
        confirmations = int(
            self.config.risk_pseudo_visits if is_risk
            else self.config.unlabeled_pseudo_visits)

        previous = self.pseudo_prediction[indices]
        same = (previous >= 0) & (previous == targets)
        self.pseudo_streak[indices] = np.where(
            same, self.pseudo_streak[indices] + 1, 1)
        self.pseudo_prediction[indices] = targets
        accepted = (
            (confidence >= thresholds)
            & (self.pseudo_streak[indices] >= confirmations))

        if is_risk:
            if observed_targets is None:
                raise ValueError('Risk pseudo labels require observed targets.')
            visible = np.asarray(observed_targets, dtype=np.int64)[indices]
            # Client risk is a prior rather than a hard exclusion rule. Strong
            # sample evidence can recover a missed noisy sample on an otherwise
            # low-risk client.
            client_or_sample_gate = (
                bool(client_is_high_risk)
                | (self.sample_risk[indices]
                   >= float(self.config.risk_sample_override)))
            accepted &= client_or_sample_gate
            accepted &= np.isin(
                self.sample_state[indices], [SUSPECT, RECOVERED])
            accepted &= targets != visible
            if commit:
                # Recovery state follows current evidence, while the returned
                # training mask also obeys each sample's finite pseudo budget.
                self.sample_state[indices[accepted]] = RECOVERED
                failed = ~accepted & (
                    self.sample_state[indices] == RECOVERED)
                self.sample_state[indices[failed]] = SUSPECT
                accepted &= (
                    self.risk_pseudo_uses[indices]
                    < int(self.config.risk_pseudo_budget))
                self.risk_pseudo_uses[indices[accepted]] += 1

        # R_i uses continuous risk/confidence evidence instead of a hard
        # sample-risk threshold. U_i keeps unit mass after acceptance.
        weights = (
            np.clip(self.sample_risk[indices] * confidence, 0.0, 1.0)
            if is_risk else np.ones(len(indices), dtype=np.float64))

        return {
            'source': source,
            'indices': indices,
            'targets': targets.astype(np.int64),
            'accepted': accepted,
            'weights': weights,
            'probabilities': probabilities.astype(np.float32),
            'confidence': confidence,
            'threshold': float(thresholds.mean()) if len(thresholds) else float(
                self.config.risk_pseudo_threshold if is_risk
                else self.config.unlabeled_pseudo_threshold),
        }

    def build_soft_correction_plan(
            self, risk_plan, observed_targets, client_is_high_risk):
        """Build bounded soft targets for persistent suspect labels.

        This path is independent from hard ``R_i`` recovery. It can start
        after two consistent teacher visits, while hard replacement retains
        the original strict confidence, confirmation, and budget gates.
        """
        indices = np.asarray(risk_plan['indices'], dtype=np.int64)
        empty_targets = np.empty(
            (len(indices), self.num_classes), dtype=np.float32)
        if not len(indices):
            return {
                'indices': indices,
                'targets': np.full(len(indices), -1, dtype=np.int64),
                'applied': np.zeros(len(indices), dtype=bool),
                'soft_targets': empty_targets,
                'alpha': np.zeros(len(indices), dtype=np.float32),
                'confidence': np.asarray(risk_plan['confidence']),
                'threshold': 1.0,
            }

        probabilities = np.asarray(
            risk_plan['probabilities'], dtype=np.float64)
        confidence = probabilities.max(axis=1)
        predicted = probabilities.argmax(axis=1)
        visible = np.asarray(observed_targets, dtype=np.int64)[indices]
        threshold = float(self.config.risk_soft_high_recall_confidence)
        persistent = self.pseudo_streak[indices] >= 2
        suspect = np.isin(
            self.sample_state[indices], [SUSPECT, RECOVERED])
        client_gate = (
            bool(client_is_high_risk)
            | (self.sample_risk[indices]
               >= float(self.config.risk_sample_override)))
        applied = (
            persistent
            & suspect
            & client_gate
            & (predicted != visible)
            & (confidence >= threshold)
        )

        soft_targets = np.clip(probabilities.copy(), 1e-8, None)
        soft_targets /= soft_targets.sum(axis=1, keepdims=True)
        alpha = np.zeros(len(indices), dtype=np.float64)
        alpha[applied] = np.clip(
            float(self.config.risk_soft_max_alpha)
            * self.sample_risk[indices[applied]]
            * confidence[applied],
            0.05,
            float(self.config.risk_soft_max_alpha),
        )
        self.soft_correction_uses[indices[applied]] += 1
        return {
            'indices': indices,
            'targets': predicted.astype(np.int64),
            'applied': applied,
            'soft_targets': soft_targets.astype(np.float32),
            'alpha': alpha.astype(np.float32),
            'confidence': confidence,
            'threshold': float(threshold),
        }

    def observe_risk_readiness(self, plans, round_index):
        """Unlock R_i after enough mature candidates persist for three rounds."""
        total = sum(len(plan['indices']) for plan in plans)
        mature = sum(int(plan['accepted'].sum()) for plan in plans)
        activated = False
        if self.risk_start_round is None:
            if mature >= int(self.config.risk_ready_min_samples):
                self.risk_readiness_streak += 1
            else:
                self.risk_readiness_streak = 0
            if self.risk_readiness_streak >= int(
                    self.config.risk_ready_rounds):
                self.risk_start_round = int(round_index) + 1
                activated = True
        return {
            'total': int(total),
            'mature': int(mature),
            'streak': int(self.risk_readiness_streak),
            'start_round': self.risk_start_round,
            'activated': activated,
        }


from pathlib import Path

import numpy as np
import torch
from torchvision import datasets, transforms
from torch.utils.data import Dataset

from util.sampling import (
    add_noise,
    iid_sampling,
    non_iid_dirichlet_sampling,
    split_labeled_unlabeled,
    write_log,
)


DATA_ROOT = Path(__file__).resolve().parents[2] / 'data'
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
CIFAR100_MEAN = (0.507, 0.487, 0.441)
CIFAR100_STD = (0.267, 0.256, 0.276)


class IndexedImageDataset(Dataset):
    """Expose a fixed image split with labels that can be safely rewritten."""

    def __init__(self, base_dataset, indices):
        self.base_dataset = base_dataset
        self.indices = np.asarray(indices, dtype=np.int64)
        self.targets = np.asarray([
            base_dataset.targets[int(index)] for index in self.indices
        ], dtype=np.int64).tolist()
        self.classes = list(base_dataset.classes)
        self.class_to_idx = dict(base_dataset.class_to_idx)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, position):
        image, _ = self.base_dataset[int(self.indices[int(position)])]
        # Read from this wrapper so prepare_scenario can replace visible labels
        # without changing the hidden labels held by the audit arrays.
        return image, int(self.targets[int(position)])


def _load_fmnist():
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    root = DATA_ROOT / 'fashionmnist'
    train = datasets.FashionMNIST(
        root, train=True, download=True, transform=transform)
    test = datasets.FashionMNIST(
        root, train=False, download=True, transform=transform)
    return train, test, np.asarray(train.targets), 10, 'fashionlenet'


def _cifar_transforms(mean, std):
    train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    return train, test


def _load_cifar10():
    train_transform, test_transform = _cifar_transforms(
        IMAGENET_MEAN, IMAGENET_STD)
    root = DATA_ROOT / 'cifar10'
    train = datasets.CIFAR10(
        root, train=True, download=True, transform=train_transform)
    test = datasets.CIFAR10(
        root, train=False, download=True, transform=test_transform)
    return train, test, np.asarray(train.targets), 10, 'resnet18'


def _load_cifar100():
    train_transform, test_transform = _cifar_transforms(
        CIFAR100_MEAN, CIFAR100_STD)
    root = DATA_ROOT / 'cifar100'
    train = datasets.CIFAR100(
        root, train=True, download=True, transform=train_transform)
    test = datasets.CIFAR100(
        root, train=False, download=True, transform=test_transform)
    return train, test, np.asarray(train.targets), 100, 'resnet34'


def _animal10_transforms():
    """Use the frozen 32x32 protocol for the natural-image experiment."""
    train = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    test = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    return train, test


def _animal10_stratified_split(targets, seed, train_fraction=0.8):
    """Create one deterministic, class-stratified train/test split."""
    targets = np.asarray(targets, dtype=np.int64).reshape(-1)
    rng = np.random.RandomState(int(seed))
    train_indices, test_indices = [], []
    for class_id in np.unique(targets):
        positions = np.where(targets == class_id)[0]
        positions = rng.permutation(positions)
        train_count = int(round(len(positions) * float(train_fraction)))
        train_count = min(max(train_count, 1), len(positions) - 1)
        train_indices.extend(positions[:train_count].tolist())
        test_indices.extend(positions[train_count:].tolist())
    return (np.asarray(sorted(train_indices), dtype=np.int64),
            np.asarray(sorted(test_indices), dtype=np.int64))


def _validate_animal10_pair(train, test):
    """Reject train/test folders whose class semantics do not match."""
    if train.class_to_idx != test.class_to_idx:
        raise ValueError(
            'Animal-10 train/test class mappings differ; fix the dataset '
            'folders before running the experiment.')
    if len(train.classes) != 10:
        raise ValueError(
            f'Animal-10 must contain exactly 10 classes, found {len(train.classes)}.')


def _load_animal10(args):
    """Load Animals-10 from raw-img or an already prepared train/test split."""
    root = DATA_ROOT / 'animal10'
    train_transform, test_transform = _animal10_transforms()

    # A pre-split layout is supported for compatibility, but raw-img is the
    # recommended layout because the code can freeze its own 80/20 split.
    split_pairs = (
        (root / 'train_dataset', root / 'val_dataset'),
        (root / 'train', root / 'test'),
    )
    for train_root, test_root in split_pairs:
        if train_root.is_dir() and test_root.is_dir():
            train = datasets.ImageFolder(train_root, transform=train_transform)
            test = datasets.ImageFolder(test_root, transform=test_transform)
            _validate_animal10_pair(train, test)
            return train, test, np.asarray(train.targets), 10, 'resnet34'

    raw_root = root / 'raw-img'
    if not raw_root.is_dir():
        archive = DATA_ROOT / 'animals10.zip'
        hint = (
            f' Extract it into {root} first (for example: '
            f'Expand-Archive {archive} -DestinationPath {root}).'
            if archive.is_file() else '')
        raise FileNotFoundError(
            f'Animals-10 data not found at {raw_root}.{hint}')

    raw_train = datasets.ImageFolder(raw_root, transform=train_transform)
    raw_test = datasets.ImageFolder(raw_root, transform=test_transform)
    _validate_animal10_pair(raw_train, raw_test)
    train_indices, test_indices = _animal10_stratified_split(
        raw_train.targets, args.seed)
    # The wrapper keeps the compact 0..len(train)-1 index space and makes sure
    # later noise injection updates the labels consumed by local training.
    train = IndexedImageDataset(raw_train, train_indices)
    test = IndexedImageDataset(raw_test, test_indices)
    return train, test, np.asarray(train.targets), 10, 'resnet34'


DATASET_LOADERS = {
    'fmnist': _load_fmnist,
    'cifar10': _load_cifar10,
    'cifar100': _load_cifar100,
}


def get_dataset(args):
    """Load one paper dataset and create its deterministic client split."""
    if args.dataset == 'animal10':
        train, test, targets, num_classes, model_name = _load_animal10(args)
    else:
        try:
            loader = DATASET_LOADERS[args.dataset]
        except KeyError as error:
            raise ValueError(f'Unsupported dataset: {args.dataset}') from error
        train, test, targets, num_classes, model_name = loader()
    args.num_classes = num_classes
    args.model = model_name

    if args.iid:
        users = iid_sampling(len(train), args.num_users, args.seed)
    else:
        users = non_iid_dirichlet_sampling(
            targets,
            args.num_classes,
            args.non_iid_prob_class,
            args.num_users,
            args.seed,
            args.alpha_dirichlet,
        )
    return train, test, targets, users


def prepare_scenario(args, log_path):
    """Create L_i/U_i, then corrupt visible labels in L_i only."""
    train, test, true_targets, users = get_dataset(args)
    labeled_users, unlabeled_users = split_labeled_unlabeled(
        users, true_targets, args.unlabeled_ratio, args.seed,
        min_labeled=max(10, args.local_bs))
    noisy_targets, _, _ = add_noise(
        args, true_targets, labeled_users, log_path)

    unlabeled_indices = set().union(*unlabeled_users.values())
    corrupted = np.asarray(noisy_targets != true_targets, dtype=bool)
    if set(np.where(corrupted)[0]) & unlabeled_indices:
        raise RuntimeError('Synthetic noise leaked into U_i.')
    visible_targets = np.asarray(noisy_targets, dtype=np.int64).copy()
    visible_targets[sorted(unlabeled_indices)] = -1
    if args.dataset == 'fmnist':
        train.targets = torch.as_tensor(visible_targets, dtype=torch.long)
    else:
        train.targets = visible_targets.tolist()

    message = (
        f'scenario: labeled={sum(map(len, labeled_users.values()))}, '
        f'unlabeled={sum(map(len, unlabeled_users.values()))}, '
        f'corrupted_labeled={int(corrupted.sum())}')
    print(message)
    write_log(message, log_path)
    return {
        'train': train,
        'test': test,
        'visible_targets': visible_targets,
        'labeled_users': labeled_users,
        'unlabeled_users': unlabeled_users,
    }

# python version 3.7.1
# -*- coding: utf-8 -*-

import copy


def FedAvg(w, dict_len):
    if not w:
        raise ValueError('FedAvg requires at least one local model.')
    if len(w) != len(dict_len):
        raise ValueError('FedAvg model and weight counts must match.')
    total_weight = float(sum(dict_len))
    if total_weight <= 0.0:
        raise ValueError('FedAvg weights must have positive total mass.')
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        # BatchNorm counters and similar integer buffers are model state, not
        # averageable parameters. Preserve the first selected client's value.
        if not w_avg[k].is_floating_point():
            continue
        w_avg[k] = w_avg[k] * float(dict_len[0])
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * float(dict_len[i])
        w_avg[k] = w_avg[k] / total_weight
    return w_avg

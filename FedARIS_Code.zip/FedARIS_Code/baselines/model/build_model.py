from model.model_simple import LeNet
from model.model_resnet import ResNet18, ResNet34


def build_model(args):
    # choose different Neural network model for different args or input
    if args.model == 'lenet':
        net_glob = LeNet().to(args.device)

    elif args.model == 'resnet18':
        net_glob = ResNet18(args.num_classes)
        net_glob = net_glob.to(args.device)

    elif args.model == 'resnet34':
        net_glob = ResNet34(args.num_classes)
        net_glob = net_glob.to(args.device)

    else:
        exit('Error: unrecognized model')

    return net_glob

"""Unified launcher for the comparison methods used by the experiments.

All methods share the same data partition, label-hiding protocol, noise
instance, client sampling budget, model builder, and evaluation pipeline.
Method-specific behavior is delegated to the baseline modules under ``util``.
"""

import os
import copy
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.mixture import GaussianMixture
from collections import defaultdict
from datetime import datetime
import warnings

from util.options import args_parser
from util.local_training import LocalUpdate, DALUpdate, ELC
from util.fedavg import FedAvg, ImpFedAvg, DeAgg
from util.util import add_noise, dal_reliability_score, dal_noise_client, get_set_gpus, write_log
from util.fedcorr import run_fedcorr
from util.metrics import ClassificationTracker
from util.ssl_baselines import SSL_METHODS, run_ssl_baseline
from util.dataset import get_dataset
from model.build_model import build_model
from util.local_training import DatasetSplit
from util.sampling import split_labeled_unlabeled
from util.target_labels import apply_training_targets, read_training_targets

os.environ["KMP_DUPLICATE_LIB_OK"]="True"
np.set_printoptions(threshold=np.inf)
warnings.filterwarnings("ignore")


def finish_run(started_at, filename, history):
    """Write only the final paper metrics and elapsed time."""
    elapsed_seconds = int((datetime.now() - started_at).total_seconds())
    hours, remainder = divmod(elapsed_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    time_str = f'train time: {hours:02d}:{minutes:02d}:{seconds:02d}'
    print(time_str)
    write_log(time_str, filename)
    if history:
        tail = history[-min(10, len(history)):]
        write_log(
            'last10 acc=%.6f, macro_f1=%.6f'
            % (
                np.mean([row['accuracy'] for row in tail]),
                np.mean([row['macro_f1'] for row in tail]),
            ),
            filename,
        )
    torch.cuda.empty_cache()


if __name__ == '__main__':
    # parse args
    args = args_parser()
    # check time and gpu
    prev_time = datetime.now()
    if args.gpu:
        gpus = get_set_gpus(args.gpu)
        print(f"{torch.cuda.is_available()}, currently use GPU: {gpus}")

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    '--------------------------------STEP1 divide dataset and add noise--------------------------------'
    dataset_train, dataset_test, y_train, dict_users = get_dataset(args)
    distribution = (
        'iid'
        if args.iid else
        f'p{args.non_iid_prob_class:g}-a{args.alpha_dirichlet:g}'
    )
    os.makedirs('result', exist_ok=True)
    filename = (
        f"result/{args.method}-{args.dataset}-{args.model}"
        f"-{args.level_n_system}-{args.level_n_lowerb}"
        f"-u{args.unlabeled_ratio}-{distribution}-s{args.seed}"
        f"-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    )
    # filename = f"result/noise-detection-{args.dataset}-{args.model}.txt"
    # write_log(f"\nmethod: {args.method}, noisy client ratio: {args.level_n_system}, lower bound: {args.level_n_lowerb}", filename)
    dict_labeled_users, dict_unlabeled_users = split_labeled_unlabeled(
        dict_users,
        y_train,
        args.unlabeled_ratio,
        args.seed,
        mode='stratified',
        min_labeled=args.local_bs,
    )
    y_train_noisy, _, _ = add_noise(
        args, y_train, dict_labeled_users, filename
    )
    unlabeled_indices = set().union(*dict_unlabeled_users.values())
    corrupted_indices = set(np.where(y_train != y_train_noisy)[0].tolist())
    if corrupted_indices & unlabeled_indices:
        raise RuntimeError('Noise was injected into the hidden unlabeled split.')
    target_storage = apply_training_targets(dataset_train, y_train_noisy)
    effective_targets = read_training_targets(dataset_train)
    target_mismatch_count = int(np.count_nonzero(
        effective_targets != np.asarray(y_train_noisy).reshape(-1)
    ))
    if target_mismatch_count:
        raise RuntimeError(
            'Injected labels do not match the labels read by the training dataset: '
            f'mismatches={target_mismatch_count}, storage={target_storage}'
        )
    if (args.level_n_system > 0 and args.level_n_lowerb > 0
            and dict_labeled_users and not corrupted_indices):
        raise RuntimeError(
            'Noise was requested but no labeled training target was changed.'
        )

    noise_message = (
        f'noise application: storage={target_storage}, '
        f'corrupted_labeled={len(corrupted_indices)}, '
        f'target_mismatches={target_mismatch_count}'
    )
    print(noise_message)
    write_log(noise_message, filename)

    labeled_count = sum(len(indices) for indices in dict_labeled_users.values())
    unlabeled_count = sum(len(indices) for indices in dict_unlabeled_users.values())
    split_message = (
        f'data split: labeled={labeled_count}, unlabeled={unlabeled_count}'
    )
    print(split_message)
    write_log(split_message, filename)

    np.random.seed(args.seed)

    # build model
    net_glob = build_model(args)
    write_log(
        'config: method=%s, seed=%d, rounds=%d, local_ep=%d, '
        'clients=%d, frac=%.4f, unlabeled_ratio=%.4f'
        % (
            args.method,
            args.seed,
            args.rounds,
            args.local_ep,
            args.num_users,
            args.frac1,
            args.unlabeled_ratio,
        ),
        filename,
    )

    if args.method in SSL_METHODS:
        preprocessing_rounds = 0
        if args.method == 'fedcorr_fixmatch':
            preprocessing = run_fedcorr(
                args,
                dataset_train,
                dataset_test,
                dict_labeled_users,
                net_glob,
                filename,
                preprocess_only=True,
            )
            net_glob = preprocessing['model']
            preprocessing_rounds = preprocessing['preprocessing_rounds']
        training_rounds = args.rounds - preprocessing_rounds
        if training_rounds < 1:
            raise ValueError(
                f'{args.method} needs more than {preprocessing_rounds} total '
                'rounds to leave at least one evaluation round.')
        result = run_ssl_baseline(
            args,
            dataset_train,
            dataset_test,
            dict_labeled_users,
            dict_unlabeled_users,
            net_glob,
            filename,
            start_round=preprocessing_rounds,
            total_rounds=training_rounds,
        )
        finish_run(prev_time, filename, result['history'])
        raise SystemExit(0)

    # Supervised comparison methods may only access L_i.
    dict_users = dict_labeled_users
    dal_methods = {'feddal'}
    noisy_clients = []
    clean_clients = []

    if args.method == 'fedcorr':
        result = run_fedcorr(
            args,
            dataset_train,
            dataset_test,
            dict_users,
            net_glob,
            filename,
        )
        finish_run(prev_time, filename, result['history'])
        raise SystemExit(0)

    net_local = build_model(args)
    preprocessing_iterations = (
        args.iteration if args.method in {'fedelc', 'feddal'} else 0)


    '--------------------------------STEP2 first stage training--------------------------------'
    reli_scores = torch.zeros(args.num_users) if args.method in dal_methods else None
    for iter in range(preprocessing_iterations):
        print('---------Pre-training the {} iteration---------'.format(iter))
        w_glob = net_glob.state_dict()
        w_locals = [copy.deepcopy(w_glob)] * args.num_users
        loss_locals = [0] * args.num_users
        for idx in range(args.num_users):
            net_local.load_state_dict(w_glob)
            sample_idx = np.array(list(dict_users[idx]))
            local = LocalUpdate(args = args, dataset = dataset_train, idxs = sample_idx)
            if args.method in dal_methods:
                w, loss = local.dal_update(net=copy.deepcopy(net_glob).to(args.device), epoch=args.local_ep, seed=args.seed)
            else:
                w, loss = local.normal_update(net=copy.deepcopy(net_glob).to(args.device), epoch=args.local_ep, seed=args.seed)
            w_locals[idx]=copy.deepcopy(w)
            loss_locals[idx]=copy.deepcopy(loss)

        client_datalen = [len(dict_users[idx]) for idx in range(args.num_users)]
        if args.method in dal_methods:
            reli_score = dal_reliability_score(args, loss_locals, client_datalen, filename)
            reli_scores = reli_scores + reli_score
            avg_glob = ImpFedAvg(w_locals, client_datalen, loss_locals)
        else:
            avg_glob = FedAvg(w_locals, client_datalen, loss_locals)
        net_glob.load_state_dict(avg_glob)

        if args.method in dal_methods and iter == preprocessing_iterations - 1:
            reli_scores = reli_scores / preprocessing_iterations
            noisy_clients = dal_noise_client(reli_scores, args.std_num, args.delta)
            print('reliability scores:', reli_scores)
            write_log(f"reliability scores: {reli_scores}", filename)
            print('noise clients:', noisy_clients)
            write_log(f"noise clients: {noisy_clients}, len: {len(noisy_clients)}", filename)

        if args.method == 'fedelc':
            if iter == 0:
                metrics = np.zeros((args.num_users, args.num_classes))
                ce = nn.CrossEntropyLoss(reduction='none')
                for idx in range(args.num_users):
                    sample_idx = np.array(list(dict_users[idx]))
                    class_loss = np.zeros(args.num_classes)
                    class_count = np.zeros(args.num_classes)

                    loader = DataLoader(DatasetSplit(dataset_train, sample_idx), batch_size=args.local_bs, shuffle=True)
                    for data, labels in loader:
                        data, labels = data.to(args.device), labels.to(args.device)
                        if data.size(0) <= 1: continue

                        logits = net_glob(data)
                        labels = labels.view(-1).long()
                        losses = ce(logits, labels).cpu().detach().numpy()
                        for label, loss in zip(labels.cpu().numpy(), losses):
                            class_loss[label] += loss
                            class_count[label] += 1

                    loss_collect = []
                    for cls in range(args.num_classes):
                        if class_count[cls] > 0:
                            loss_collect.append(class_loss[cls] / class_count[cls])
                            metrics[idx, cls] = class_loss[cls] / class_count[cls]
                    for cls in range(args.num_classes):
                        if class_count[cls] == 0:
                            metrics[idx, cls] = min(loss_collect)

                for cls in range(args.num_classes):
                    col = metrics[:, cls]
                    min_val, max_val = col.min(), col.max()
                    if max_val - min_val > 1e-6:
                        metrics[:, cls] = (col - min_val) / (max_val - min_val)
                    else:
                        metrics[:, cls] = 0.0

                vote = []
                for seed in range(9):
                    gmm = GaussianMixture(n_components=2, random_state=seed)
                    gmm.fit(metrics)

                    noisy_cluster_id = np.argmax(gmm.means_.sum(axis=1))
                    pred_labels = gmm.predict(metrics)
                    noisy_clients = np.where(pred_labels == noisy_cluster_id)[0]
                    vote.append(set(noisy_clients))

                cluster_cnt = defaultdict(int)
                for client_set in vote:
                    cluster_cnt[frozenset(client_set)] += 1

                most_common_set = max(cluster_cnt, key=lambda k: cluster_cnt[k])
                noisy_clients = list(most_common_set)
                clean_clients = list(set(range(args.num_users)) - set(noisy_clients))
                print("noisy clients: ", noisy_clients)
                write_log(f"noise clients: {noisy_clients}, len: {len(noisy_clients)}", filename)

    tracker = ClassificationTracker(filename, args.num_classes)
    training_rounds = args.rounds - preprocessing_iterations
    if training_rounds < 1:
        raise ValueError(
            f'{args.method} needs more than {preprocessing_iterations} total rounds '
            'to leave at least one evaluation round.')

    '--------------------------------STEP3 second stage training--------------------------------'
    for rnd in range(training_rounds):
        print('---------Federated training the {} round---------'.format(rnd))
        w_grob = net_glob.state_dict()
        prob = [1 / args.num_users] * args.num_users
        selected_count = min(
            max(int(args.num_users * args.frac1), 1), args.num_users)
        idxs_users = np.random.choice(
            range(args.num_users), selected_count, replace=False, p=prob)
        client_datalen = [len(dict_users[idx]) for idx in idxs_users]
        w_locals, loss_locals = [], []
        # models training
        for idx in idxs_users:
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            if args.method in dal_methods:
                if idx in noisy_clients:
                    t0 = (1 - args.qs) * args.local_ep / (args.qe - args.qs)
                    local = DALUpdate(args=args, dataset=dataset_train, idxs=sample_idx, t0=t0)
                    w_local, loss_local = local.update_weights(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)
                else:
                    local = LocalUpdate(args=args, dataset=dataset_train, idxs=sample_idx)
                    w_local, loss_local = local.dal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            elif args.method == 'fedelc':
                if idx in noisy_clients:
                    local = ELC(args=args, dataset=dataset_train, idxs=sample_idx)
                    w_local, loss_local = local.elc_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)
                else:
                    local = LocalUpdate(args=args, dataset=dataset_train, idxs=sample_idx)
                    w_local, loss_local = local.normal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            else:
                local = LocalUpdate(args=args, dataset=dataset_train, idxs=sample_idx)
                w_local, loss_local = local.normal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            w_locals.append(copy.deepcopy(w_local))
            loss_locals.append(copy.deepcopy(loss_local))
        # model aggregation
        if args.method in dal_methods:
            w_glob = ImpFedAvg(w_locals, client_datalen, loss_locals)

        elif args.method == 'fedelc':
            select_clean = [c for c in range(len(idxs_users)) if idxs_users[c] in clean_clients]
            select_noisy = [c for c in range(len(idxs_users)) if idxs_users[c] in noisy_clients]
            if len(select_clean) == 0:
                w_glob = FedAvg(w_locals, client_datalen, loss_locals)
            else:
                w_glob = DeAgg(idxs_users, client_datalen, w_locals, select_clean, select_noisy)

        else:
            w_glob = FedAvg(w_locals, client_datalen, loss_locals)
        net_glob.load_state_dict(copy.deepcopy(w_glob))

        metrics = tracker.record(
            preprocessing_iterations + rnd,
            copy.deepcopy(net_glob).to(args.device),
            dataset_test,
            args,
        )
        print(
            f'loss: {metrics["loss"]:.4f}, '
            f'acc: {metrics["accuracy"]:.4f}, '
            f'macro_f1: {metrics["macro_f1"]:.4f}'
        )
    tracker.finalize()

    finish_run(prev_time, filename, tracker.history)

import argparse


SUPPORTED_METHODS = (
    'fedavg',
    'fedprox',
    'fedelc',
    'fedcorr',
    'feddal',
    'fedmatch',
    'sage',
    'fedavg_fixmatch',
    'fedcorr_fixmatch',
)

def _validate_args(parser, args):
    if args.iteration < 1:
        parser.error('--iteration must be at least 1')
    if args.rounds < 1:
        parser.error('--rounds must be at least 1')
    if args.local_ep < 1:
        parser.error('--local_ep must be at least 1')
    if args.num_users < 1:
        parser.error('--num_users must be at least 1')
    if args.local_bs < 1:
        parser.error('--local_bs must be at least 1')
    if not 0 < args.frac1 <= 1:
        parser.error('--frac1 must be in (0, 1]')
    if args.lr <= 0:
        parser.error('--lr must be positive')
    if not 0 <= args.level_n_system <= 1:
        parser.error('--level_n_system must be in [0, 1]')
    if not 0 <= args.level_n_lowerb <= 1:
        parser.error('--level_n_lowerb must be in [0, 1]')
    if not 0 <= args.unlabeled_ratio < 1:
        parser.error('--unlabeled_ratio must be in [0, 1)')
    if not 0 < args.non_iid_prob_class <= 1:
        parser.error('--non_iid_prob_class must be in (0, 1]')
    if args.alpha_dirichlet <= 0:
        parser.error('--alpha_dirichlet must be positive')
    if args.fedcorr_lid_k < 1:
        parser.error('--fedcorr_lid_k must be at least 1')
    if args.fedcorr_finetune_rounds is not None \
            and args.fedcorr_finetune_rounds < 0:
        parser.error('--fedcorr_finetune_rounds must be non-negative')

    for name in (
            'fedcorr_relabel_ratio', 'fedcorr_confidence_thres',
            'fedcorr_clean_set_thres'):
        if not 0 <= getattr(args, name) <= 1:
            parser.error(f'--{name} must be in [0, 1]')

    if not 0 <= args.ssl_threshold <= 1:
        parser.error('--ssl_threshold must be in [0, 1]')
    if args.ssl_lambda_u < 0:
        parser.error('--ssl_lambda_u must be non-negative')
    if args.ssl_temperature <= 0:
        parser.error('--ssl_temperature must be positive')
    if args.ssl_rampup_rounds < 0:
        parser.error('--ssl_rampup_rounds must be non-negative')
    if args.ssl_num_workers < 0:
        parser.error('--ssl_num_workers must be non-negative')

    if not 0 <= args.fedmatch_confidence <= 1:
        parser.error('--fedmatch_confidence must be in [0, 1]')
    if args.fedmatch_num_helpers < 0:
        parser.error('--fedmatch_num_helpers must be non-negative')
    if args.fedmatch_helper_interval < 1:
        parser.error('--fedmatch_helper_interval must be at least 1')
    for name in (
            'fedmatch_lambda_s', 'fedmatch_lambda_agreement',
            'fedmatch_lambda_inter', 'fedmatch_lambda_l1',
            'fedmatch_lambda_l2', 'fedmatch_weight_decay',
            'fedmatch_psi_factor', 'fedmatch_l1_threshold'):
        if getattr(args, name) < 0:
            parser.error(f'--{name} must be non-negative')
    if args.fedmatch_lr <= 0:
        parser.error('--fedmatch_lr must be positive')

    if args.qe <= args.qs:
        parser.error('--qe must be greater than --qs')
    return args


def args_parser():
    parser = argparse.ArgumentParser()
    # Federated optimization
    parser.add_argument(
        '--iteration', type=int, default=1,
        help='preprocessing-stage iteration number')
    parser.add_argument(
        '--rounds', type=int, default=200,
        help='number of federated training rounds')
    parser.add_argument(
        '--local_ep', type=int, default=5,
        help='number of local epochs')
    parser.add_argument(
        '--frac1', type=float, default=0.2,
        help='fraction of clients selected per round')
    parser.add_argument(
        '--std_num', type=float, default=1,
        help='number of standard deviations from the mean')
    parser.add_argument(
        '--num_users', type=int, default=50,
        help='number of clients: K')
    parser.add_argument(
        '--local_bs', type=int, default=10,
        help='local batch size: B')
    parser.add_argument('--lr', type=float, default=0.03,
                        help='learning rate')
    parser.add_argument('--momentum', type=float, default=0.5,
                        help='SGD momentum')
    parser.add_argument('--beta', type=float, default=1.0,
                        help='FedProx proximal coefficient')
    parser.add_argument(
        '--gpu', default='0,1',
        help='comma-separated list of GPUs to use')
    parser.add_argument('--device', type=str, default='cuda')

    # Label noise
    parser.add_argument('--delta', type=int, default=20, help="tolerance value")
    parser.add_argument(
        '--level_n_system', type=float, default=0.4,
        help='fraction of noisy clients, e.g. 0.4 or 0.7')
    parser.add_argument(
        '--level_n_lowerb', type=float, default=0.3,
        help='lower noise-rate bound, e.g. 0.3, 0.5 or 0.7')

    # Labeled/unlabeled split
    parser.add_argument('--unlabeled_ratio', type=float, default=0.0)

    # FedCorr
    parser.add_argument('--fedcorr_lid_k', type=int, default=20)
    parser.add_argument('--fedcorr_beta', type=float, default=5.0)
    parser.add_argument('--fedcorr_relabel_ratio', type=float, default=0.5)
    parser.add_argument('--fedcorr_confidence_thres', type=float, default=0.5)
    parser.add_argument('--fedcorr_clean_set_thres', type=float, default=0.1)
    parser.add_argument('--fedcorr_finetune_rounds', type=int, default=None)
    parser.add_argument('--fedcorr_mixup_alpha', type=float, default=1.0)

    # Shared semi-supervised settings
    parser.add_argument('--ssl_threshold', type=float, default=0.95)
    parser.add_argument('--ssl_lambda_u', type=float, default=1.0)
    parser.add_argument('--ssl_temperature', type=float, default=1.0)
    parser.add_argument('--ssl_rampup_rounds', type=int, default=0)
    parser.add_argument('--ssl_randaug_ops', type=int, default=2)
    parser.add_argument('--ssl_randaug_magnitude', type=int, default=10)
    parser.add_argument('--ssl_weight_decay', type=float, default=0.0)
    parser.add_argument('--ssl_num_workers', type=int, default=0)

    # SAGE
    parser.add_argument('--sage_kappa', type=float, default=13.8629436112)

    # FedMatch
    parser.add_argument('--fedmatch_confidence', type=float, default=0.75)
    parser.add_argument('--fedmatch_num_helpers', type=int, default=2)
    parser.add_argument('--fedmatch_helper_interval', type=int, default=10)
    parser.add_argument('--fedmatch_lambda_s', type=float, default=10.0)
    parser.add_argument('--fedmatch_lambda_agreement', type=float, default=0.01)
    parser.add_argument('--fedmatch_lambda_inter', type=float, default=0.01)
    parser.add_argument('--fedmatch_lambda_l1', type=float, default=1e-4)
    parser.add_argument('--fedmatch_lambda_l2', type=float, default=10.0)
    parser.add_argument('--fedmatch_lr', type=float, default=1e-3)
    parser.add_argument('--fedmatch_weight_decay', type=float, default=1e-4)
    parser.add_argument('--fedmatch_psi_factor', type=float, default=0.2)
    parser.add_argument('--fedmatch_l1_threshold', type=float, default=5e-6)

    # Experiment and dataset
    parser.add_argument(
        '--method', type=str, choices=SUPPORTED_METHODS, default='fedavg',
        help='method name')
    parser.add_argument(
        '--dataset', choices=('fmnist', 'cifar10', 'cifar100', 'animal10'),
        default='cifar10')
    parser.add_argument('--iid', action='store_true', default=False, help="i.i.d. or non-i.i.d.")
    parser.add_argument(
        '--non_iid_prob_class', type=float, default=0.7,
        help='non-IID class sampling probability')
    parser.add_argument('--alpha_dirichlet', type=float, default=10)
    parser.add_argument('--seed', type=int, default=6, help="random seed, default: 6")
    parser.add_argument("--qs", type=float, default=0.6)
    parser.add_argument("--qe", type=float, default=1.5)
    return _validate_args(parser, parser.parse_args())

import numpy as np


def iid_sampling(n_train, num_users, seed):
    rng = np.random.RandomState(seed)
    client_splits = np.array_split(rng.permutation(n_train), num_users)
    return {client_id: set(indices.tolist()) for client_id, indices in enumerate(client_splits)}


def non_iid_dirichlet_sampling(y_train, num_classes, p, num_users, seed,
                               alpha_dirichlet=10, min_client_size=1):
    rng = np.random.RandomState(seed)
    Phi = rng.binomial(1, p, size=(num_users, num_classes))  # indicate the classes chosen by each client
    n_classes_per_client = np.sum(Phi, axis=1)
    while np.min(n_classes_per_client) == 0:
        invalid_idx = np.where(n_classes_per_client==0)[0]
        Phi[invalid_idx] = rng.binomial(1, p, size=(len(invalid_idx), num_classes))
        n_classes_per_client = np.sum(Phi, axis=1)
    for class_id in np.where(Phi.sum(axis=0) == 0)[0]:
        Phi[rng.randint(0, num_users), class_id] = 1
    Psi = [list(np.where(Phi[:, j]==1)[0]) for j in range(num_classes)]   # indicate the clients that choose each class
    num_clients_per_class = np.array([len(x) for x in Psi])
    dict_users = {client_id: set() for client_id in range(num_users)}
    for class_i in range(num_classes):
        all_idxs = np.where(y_train==class_i)[0]
        p_dirichlet = rng.dirichlet([alpha_dirichlet] * num_clients_per_class[class_i])
        assignment = rng.choice(Psi[class_i], size=len(all_idxs), p=p_dirichlet.tolist())

        for client_k in Psi[class_i]:
            dict_users[client_k].update(all_idxs[assignment == client_k].tolist())

    feasible_minimum = min(
        max(int(min_client_size), 1), len(y_train) // num_users)
    undersized_clients = [
        client_id for client_id, indices in dict_users.items()
        if len(indices) < feasible_minimum]
    for client_id in undersized_clients:
        while len(dict_users[client_id]) < feasible_minimum:
            donor = max(dict_users, key=lambda key: len(dict_users[key]))
            if len(dict_users[donor]) <= feasible_minimum:
                raise RuntimeError(
                    'Cannot satisfy the minimum non-IID client size.')
            candidates = np.asarray(sorted(dict_users[donor]), dtype=np.int64)
            moved = int(rng.choice(candidates))
            dict_users[donor].remove(moved)
            dict_users[client_id].add(moved)
    return dict_users


def split_labeled_unlabeled(dict_users, targets, unlabeled_ratio, seed,
                            mode='stratified', min_labeled=1):
    if not 0 <= unlabeled_ratio < 1:
        raise ValueError('unlabeled_ratio must be in [0, 1).')
    if mode not in {'stratified', 'random'}:
        raise ValueError("mode must be either 'stratified' or 'random'.")
    if min_labeled < 1:
        raise ValueError('min_labeled must be at least 1.')

    targets = np.asarray(targets).reshape(-1)
    rng = np.random.RandomState(seed)
    labeled_users = {}
    unlabeled_users = {}

    for client_id in sorted(dict_users):
        client_indices = np.asarray(sorted(dict_users[client_id]), dtype=np.int64)
        client_size = len(client_indices)
        unlabeled_count = min(
            int(round(client_size * unlabeled_ratio)),
            max(client_size - min_labeled, 0),
        )

        if unlabeled_count == 0:
            unlabeled_indices = np.empty(0, dtype=np.int64)
        elif mode == 'random':
            unlabeled_indices = rng.choice(
                client_indices, size=unlabeled_count, replace=False
            )
        else:
            unlabeled_indices = _stratified_unlabeled_indices(
                client_indices, targets, unlabeled_count, rng
            )

        unlabeled_set = set(unlabeled_indices.tolist())
        labeled_set = set(client_indices.tolist()) - unlabeled_set
        if labeled_set & unlabeled_set or labeled_set | unlabeled_set != set(client_indices):
            raise RuntimeError(f'Invalid labeled/unlabeled split for client {client_id}.')

        labeled_users[client_id] = labeled_set
        unlabeled_users[client_id] = unlabeled_set

    return labeled_users, unlabeled_users


def _stratified_unlabeled_indices(client_indices, targets, unlabeled_count, rng):
    client_targets = targets[client_indices]
    classes, counts = np.unique(client_targets, return_counts=True)
    ideal = unlabeled_count * counts / counts.sum()
    quotas = np.floor(ideal).astype(int)

    # Keep one labeled example per local class whenever the requested ratio permits it.
    preferred_capacity = np.maximum(counts - 1, 0)
    quotas = np.minimum(quotas, preferred_capacity)
    remaining = unlabeled_count - int(quotas.sum())
    fractional_order = np.argsort(-(ideal - np.floor(ideal)))

    while remaining > 0:
        progressed = False
        for class_pos in fractional_order:
            if quotas[class_pos] < preferred_capacity[class_pos]:
                quotas[class_pos] += 1
                remaining -= 1
                progressed = True
                if remaining == 0:
                    break
        if not progressed:
            break

    # Very high unlabeled ratios may require consuming singleton classes as well.
    while remaining > 0:
        progressed = False
        for class_pos in fractional_order:
            if quotas[class_pos] < counts[class_pos]:
                quotas[class_pos] += 1
                remaining -= 1
                progressed = True
                if remaining == 0:
                    break
        if not progressed:
            raise RuntimeError('Unable to satisfy the requested unlabeled ratio.')

    selected = []
    for class_id, quota in zip(classes, quotas):
        class_indices = client_indices[client_targets == class_id]
        if quota > 0:
            selected.extend(rng.choice(class_indices, size=quota, replace=False).tolist())
    return np.asarray(selected, dtype=np.int64)



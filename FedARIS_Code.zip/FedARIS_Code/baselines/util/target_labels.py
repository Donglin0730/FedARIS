"""Apply and verify mutable training targets across torchvision datasets."""

from __future__ import annotations

import numpy as np


def _as_int_vector(targets):
    values = np.asarray(targets, dtype=np.int64).reshape(-1)
    return values


def _coerce_like(original, values):
    if isinstance(original, np.ndarray):
        return values.astype(original.dtype, copy=True)
    if hasattr(original, "new_tensor"):
        return original.new_tensor(values.tolist())
    if isinstance(original, tuple):
        return tuple(int(value) for value in values)
    return [int(value) for value in values]


def apply_training_targets(dataset, targets):
    """Replace labels in the storage actually read by ``dataset[index]``.

    ``torchvision.datasets.ImageFolder`` reads labels from ``samples`` rather
    than ``targets``. Updating only ``targets`` therefore leaves training labels
    unchanged. For ImageFolder-like datasets we update ``samples``, ``imgs``
    and ``targets`` together. Other torchvision/MedMNIST datasets retain their
    native target container type where practical.

    Returns the name of the authoritative storage that was updated.
    """
    values = _as_int_vector(targets)
    if len(dataset) != len(values):
        raise ValueError(
            f"target count mismatch: dataset={len(dataset)}, targets={len(values)}"
        )

    if hasattr(dataset, "samples"):
        samples = list(dataset.samples)
        if len(samples) != len(values):
            raise ValueError(
                "ImageFolder sample count does not match the supplied targets"
            )
        updated = [
            (sample[0], int(values[index]), *sample[2:])
            for index, sample in enumerate(samples)
        ]
        dataset.samples = updated
        if hasattr(dataset, "imgs"):
            dataset.imgs = dataset.samples
        dataset.targets = [int(value) for value in values]
        return "samples"

    if hasattr(dataset, "labels"):
        original = dataset.labels
        shaped = values.reshape(-1, 1) if np.asarray(original).ndim == 2 else values
        dataset.labels = _coerce_like(original, shaped)
        return "labels"

    if hasattr(dataset, "targets"):
        dataset.targets = _coerce_like(dataset.targets, values)
        return "targets"

    raise TypeError(
        f"unsupported dataset type for target replacement: {type(dataset).__name__}"
    )


def read_training_targets(dataset):
    """Read labels from the same authoritative storage used for training."""
    if hasattr(dataset, "samples"):
        return np.asarray([sample[1] for sample in dataset.samples], dtype=np.int64)
    if hasattr(dataset, "labels"):
        return _as_int_vector(dataset.labels)
    if hasattr(dataset, "targets"):
        return _as_int_vector(dataset.targets)
    raise TypeError(
        f"unsupported dataset type for target audit: {type(dataset).__name__}"
    )

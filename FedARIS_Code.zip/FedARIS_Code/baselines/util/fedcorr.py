"""Core FedCorr comparison implementation.

This module is kept separate from the shared launcher so preprocessing,
label correction, and fine-tuning remain attributable to the baseline rather
than to the common experimental protocol.
"""

import copy
import math

import numpy as np
import torch
import torch.nn.functional as F
from scipy.spatial.distance import cdist
from sklearn.mixture import GaussianMixture
from torch import nn
from torch.utils.data import DataLoader, Dataset

from util.fedavg import FedAvg
from util.metrics import ClassificationTracker
from util.util import write_log


class FedCorrDatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, index):
        return self.dataset[self.idxs[index]]


class FedCorrLocalUpdate:
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.loader = DataLoader(
            FedCorrDatasetSplit(dataset, idxs),
            batch_size=args.local_bs,
            shuffle=True,
        )
        self.loss_fn = nn.CrossEntropyLoss()

    def update_weights(self, net, global_net, epoch, mu=0.0):
        net.train()
        optimizer = torch.optim.SGD(
            net.parameters(), lr=self.args.lr, momentum=self.args.momentum
        )
        global_params = [param.detach() for param in global_net.parameters()]
        epoch_losses = []

        for _ in range(epoch):
            batch_losses = []
            for images, labels in self.loader:
                images = images.to(self.args.device)
                labels = labels.to(self.args.device).view(-1).long()
                optimizer.zero_grad()

                mixed, labels_a, labels_b, ratio = _mixup_data(
                    images, labels, self.args.fedcorr_mixup_alpha
                )
                logits = net(mixed)
                loss = ratio * self.loss_fn(logits, labels_a)
                loss += (1.0 - ratio) * self.loss_fn(logits, labels_b)

                if self.args.fedcorr_beta > 0 and mu > 0:
                    squared_distance = torch.zeros((), device=self.args.device)
                    for global_param, local_param in zip(global_params, net.parameters()):
                        squared_distance += torch.sum((global_param - local_param) ** 2)
                    loss += self.args.fedcorr_beta * mu * torch.sqrt(
                        squared_distance + 1e-12
                    )

                loss.backward()
                optimizer.step()
                batch_losses.append(loss.item())

            epoch_losses.append(float(np.mean(batch_losses)))

        return net.state_dict(), float(np.mean(epoch_losses))


def _mixup_data(images, labels, alpha):
    ratio = np.random.beta(alpha, alpha) if alpha > 0 else 1.0
    permutation = torch.randperm(images.size(0), device=images.device)
    mixed = ratio * images + (1.0 - ratio) * images[permutation]
    return mixed, labels, labels[permutation], ratio


def _get_outputs(dataset, idxs, net, args):
    loader = DataLoader(
        FedCorrDatasetSplit(dataset, idxs), batch_size=100, shuffle=False
    )
    loss_fn = nn.CrossEntropyLoss(reduction='none')
    probabilities = []
    losses = []

    net.eval()
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args.device)
            labels = labels.to(args.device).view(-1).long()
            logits = net(images)
            probabilities.append(F.softmax(logits, dim=1).cpu().numpy())
            losses.append(loss_fn(logits, labels).cpu().numpy())

    return np.concatenate(probabilities), np.concatenate(losses)


def _lid_scores(outputs, k):
    outputs = np.asarray(outputs, dtype=np.float32)
    if len(outputs) < 2:
        return np.zeros(len(outputs), dtype=np.float32)

    k = min(k, len(outputs) - 1)
    distances = cdist(outputs, outputs)
    nearest = np.sort(distances, axis=1)[:, 1:k + 1]
    furthest = nearest[:, -1:]
    denominator = np.sum(
        np.log((nearest + 1e-6) / (furthest + 1e-6)), axis=1
    )
    return -k / (denominator + 1e-6)


def _gmm_partition(values, seed):
    values = np.asarray(values, dtype=np.float64).reshape(-1, 1)
    if len(values) < 2 or np.allclose(values, values[0]):
        return np.arange(len(values)), np.array([], dtype=int)

    gmm = GaussianMixture(n_components=2, random_state=seed).fit(values)
    labels = gmm.predict(values)
    clean_cluster = int(np.argmin(gmm.means_[:, 0]))
    clean = np.where(labels == clean_cluster)[0]
    noisy = np.where(labels != clean_cluster)[0]
    return clean, noisy


def _get_targets(dataset, args):
    return np.asarray(dataset.targets).reshape(-1).copy()


def _set_targets(dataset, args, targets):
    dataset.targets = np.asarray(targets)


def _aggregate_clients(args, dataset, dict_users, net_glob, selected,
                       noise_levels):
    local_weights = []
    local_losses = []
    data_lengths = []

    for idx in selected:
        sample_idx = np.asarray(list(dict_users[int(idx)]))
        updater = FedCorrLocalUpdate(args, dataset, sample_idx)
        local_model = copy.deepcopy(net_glob).to(args.device)
        weights, loss = updater.update_weights(
            local_model,
            net_glob,
            args.local_ep,
            mu=float(noise_levels[int(idx)]),
        )
        local_weights.append(copy.deepcopy(weights))
        local_losses.append(loss)
        data_lengths.append(len(sample_idx))

    averaged = FedAvg(local_weights, data_lengths, local_losses)
    net_glob.load_state_dict(copy.deepcopy(averaged))
    return net_glob


def _correct_from_losses(args, dataset, dict_users, net_glob, noisy_clients,
                         noise_levels, sample_losses):
    targets = _get_targets(dataset, args)
    corrected = 0

    for idx in noisy_clients:
        sample_idx = np.asarray(list(dict_users[int(idx)]))
        probabilities, _ = _get_outputs(dataset, sample_idx, net_glob, args)
        count = int(
            len(sample_idx)
            * noise_levels[int(idx)]
            * args.fedcorr_relabel_ratio
        )
        high_loss = np.argsort(-sample_losses[sample_idx])[:count]
        confident = np.where(
            probabilities.max(axis=1) > args.fedcorr_confidence_thres
        )[0]
        relabel = np.intersect1d(high_loss, confident)
        pseudo_targets = probabilities.argmax(axis=1)[relabel]
        targets[sample_idx[relabel]] = pseudo_targets
        corrected += len(relabel)
    _set_targets(dataset, args, targets)
    return corrected


def _correct_from_confidence(args, dataset, dict_users, net_glob, noisy_clients):
    targets = _get_targets(dataset, args)
    corrected = 0

    for idx in noisy_clients:
        sample_idx = np.asarray(list(dict_users[int(idx)]))
        probabilities, _ = _get_outputs(dataset, sample_idx, net_glob, args)
        relabel = np.where(
            probabilities.max(axis=1) > args.fedcorr_confidence_thres
        )[0]
        pseudo_targets = probabilities.argmax(axis=1)[relabel]
        targets[sample_idx[relabel]] = pseudo_targets
        corrected += len(relabel)
    _set_targets(dataset, args, targets)
    return corrected


def run_fedcorr(args, dataset_train, dataset_test, dict_users, net_glob,
                filename, preprocess_only=False):
    net_glob = net_glob.to(args.device)
    total_samples = len(dataset_train)
    accumulated_lid = np.zeros(args.num_users)
    estimated_noise = np.zeros(args.num_users)
    noisy_clients = np.array([], dtype=int)
    clean_clients = np.arange(args.num_users)

    write_log(
        'FedCorr preprocessing: '
        f'LID_k={args.fedcorr_lid_k}, beta={args.fedcorr_beta}, '
        f'confidence={args.fedcorr_confidence_thres}',
        filename,
    )

    group_size = max(int(args.num_users * args.frac1), 1)
    rounds_per_preprocessing_iteration = math.ceil(
        args.num_users / group_size)
    preprocessing_rounds = (
        args.iteration * rounds_per_preprocessing_iteration)
    training_rounds = args.rounds - preprocessing_rounds
    if not preprocess_only and training_rounds < 1:
        raise ValueError(
            f'FedCorr needs more than {preprocessing_rounds} total rounds '
            'to leave at least one evaluation round.')
    for iteration in range(args.iteration):
        print(f'---------FedCorr preprocessing iteration {iteration}---------')
        sample_losses = np.zeros(total_samples)
        client_lid = np.zeros(args.num_users)

        client_order = np.random.permutation(args.num_users)
        for coverage_round, start in enumerate(
                range(0, args.num_users, group_size)):
            selected = client_order[start:start + group_size]
            local_weights = []
            local_losses = []
            data_lengths = []
            for idx in selected:
                sample_idx = np.asarray(list(dict_users[int(idx)]))
                updater = FedCorrLocalUpdate(args, dataset_train, sample_idx)
                local_model = copy.deepcopy(net_glob).to(args.device)
                weights, local_loss = updater.update_weights(
                    local_model,
                    net_glob,
                    args.local_ep,
                    mu=float(estimated_noise[int(idx)]),
                )
                local_weights.append(copy.deepcopy(weights))
                local_losses.append(local_loss)
                data_lengths.append(len(sample_idx))
                local_model.load_state_dict(weights)
                probabilities, losses = _get_outputs(
                    dataset_train, sample_idx, local_model, args
                )
                sample_losses[sample_idx] = losses
                local_lid = _lid_scores(
                    probabilities, args.fedcorr_lid_k)
                client_lid[int(idx)] = local_lid.mean()

            averaged = FedAvg(local_weights, data_lengths, local_losses)
            net_glob.load_state_dict(copy.deepcopy(averaged))

        accumulated_lid += client_lid
        clean_clients, noisy_clients = _gmm_partition(
            accumulated_lid, args.seed
        )
        estimated_noise = np.zeros(args.num_users)

        for idx in noisy_clients:
            sample_idx = np.asarray(list(dict_users[int(idx)]))
            clean_samples, noisy_samples = _gmm_partition(
                sample_losses[sample_idx], args.seed
            )
            del clean_samples
            estimated_noise[int(idx)] = len(noisy_samples) / len(sample_idx)

        write_log(f'FedCorr LID scores: {accumulated_lid.tolist()}', filename)
        write_log(
            f'FedCorr noise clients: {noisy_clients.tolist()}, '
            f'len: {len(noisy_clients)}',
            filename,
        )
        print('FedCorr noise clients:', noisy_clients.tolist())

        corrected = _correct_from_losses(
            args,
            dataset_train,
            dict_users,
            net_glob,
            noisy_clients,
            estimated_noise,
            sample_losses,
        )
        write_log(
            f'FedCorr preprocessing corrected labels: {corrected}', filename
        )

    eligible_clean = np.where(
        estimated_noise <= args.fedcorr_clean_set_thres
    )[0]
    if len(eligible_clean) == 0:
        eligible_clean = clean_clients

    if preprocess_only:
        return {
            'model': net_glob,
            'noisy_clients': noisy_clients,
            'clean_clients': clean_clients,
            'eligible_clean': eligible_clean,
            'estimated_noise': estimated_noise,
            'preprocessing_rounds': preprocessing_rounds,
        }

    fine_tune_rounds = args.fedcorr_finetune_rounds
    if fine_tune_rounds is None:
        fine_tune_rounds = training_rounds // 2
    fine_tune_rounds = min(max(fine_tune_rounds, 0), training_rounds)

    tracker = ClassificationTracker(filename, args.num_classes)

    clean_count = min(group_size, len(eligible_clean))
    zero_noise = np.zeros(args.num_users)
    for rnd in range(fine_tune_rounds):
        selected = np.random.choice(
            eligible_clean, clean_count, replace=False
        )
        net_glob = _aggregate_clients(
            args,
            dataset_train,
            dict_users,
            net_glob,
            selected,
            zero_noise,
        )
        metrics = tracker.record(
            preprocessing_rounds + rnd,
            copy.deepcopy(net_glob).to(args.device),
            dataset_test,
            args,
        )
        print(
            f'FedCorr fine-tuning round {rnd}: '
            f'loss={metrics["loss"]:.4f}, '
            f'acc={metrics["accuracy"]:.4f}, '
            f'macro_f1={metrics["macro_f1"]:.4f}'
        )

    corrected = _correct_from_confidence(
        args,
        dataset_train,
        dict_users,
        net_glob,
        noisy_clients,
    )
    write_log(f'FedCorr post-finetuning corrected labels: {corrected}', filename)

    all_clients = np.arange(args.num_users)
    selected_count = min(group_size, args.num_users)
    for rnd in range(fine_tune_rounds, training_rounds):
        selected = np.random.choice(
            all_clients, selected_count, replace=False
        )
        net_glob = _aggregate_clients(
            args,
            dataset_train,
            dict_users,
            net_glob,
            selected,
            zero_noise,
        )
        metrics = tracker.record(
            preprocessing_rounds + rnd,
            copy.deepcopy(net_glob).to(args.device),
            dataset_test,
            args,
        )
        print(
            f'FedCorr usual-training round {rnd}: '
            f'loss={metrics["loss"]:.4f}, '
            f'acc={metrics["accuracy"]:.4f}, '
            f'macro_f1={metrics["macro_f1"]:.4f}'
        )

    tracker.finalize()
    return {
        'history': tracker.history,
        'model': net_glob,
        'preprocessing_rounds': preprocessing_rounds,
    }

import copy
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import numpy as np


'--------------------------------Global use--------------------------------'
class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.images = torch.stack([dataset[i][0] for i in idxs])
        self.labels = torch.tensor([dataset[i][1] for i in idxs])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        return self.images[index], self.labels[index]

    @property
    def tensor(self):
        return (self.images, self.labels)


class UnlabeledDatasetSplit(Dataset):
    def __init__(self, dataset, idxs, two_views=False):
        self.dataset = dataset
        self.idxs = list(idxs)
        self.two_views = two_views

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, index):
        global_index = self.idxs[index]
        image, _ = self.dataset[global_index]
        if not self.two_views:
            return image, global_index
        second_view, _ = self.dataset[global_index]
        return image, second_view, global_index


def globaltest(net, test_dataset, args):
    net.eval()
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=100, shuffle=False, drop_last=True)
    with torch.no_grad():
        correct, total, batch_loss = 0, 0, []
        loss_fn = nn.CrossEntropyLoss()
        for images, labels in test_loader:
            images = images.to(args.device)
            labels = labels.to(args.device)
            labels = labels.view(-1).long()
            outputs = net(images)
            loss = loss_fn(outputs, labels)
            batch_loss.append(loss.item())
            _, log_probsicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (log_probsicted == labels).sum().item()
    test_loss = sum(batch_loss) / len(batch_loss)
    accuracy = round(correct / total, 4)
    return test_loss, accuracy
'--------------------------------Global use--------------------------------'


'--------------------------------FedDAL use--------------------------------'
class GCE(nn.Module):
    def __init__(self, num_classes=10, q=0.7):
        super(GCE, self).__init__()
        self.num_classes = num_classes
        self.q = q

    def forward(self, log_probs, labels):
        log_probs = F.softmax(log_probs, dim=1)
        log_probs = torch.clamp(log_probs, min=1e-6, max=1.0)
        label_one_hot = F.one_hot(labels, self.num_classes).float().to(log_probs.device)
        loss = (1. - torch.pow(torch.sum(label_one_hot * log_probs, dim=1), self.q)) / self.q
        return loss.mean()


class BS(object):
    def __call__(self, outputs):
        targets = torch.argmax(outputs, dim=1)
        return nn.CrossEntropyLoss()(outputs, targets)
'--------------------------------FedDAL use--------------------------------'


'--------------------------------FedELC use--------------------------------'
class LogitAdjust(nn.Module):
    def __init__(self, cls_num_list, tau=1, weight=None):
        super(LogitAdjust, self).__init__()
        cls_num_list = torch.as_tensor(cls_num_list, device='cuda')
        cls_p_list = cls_num_list / cls_num_list.sum()
        m_list = tau * torch.log(cls_p_list)
        self.m_list = m_list.view(1, -1)
        self.weight = weight

    def forward(self, x, target):
        x_m = x + self.m_list
        return F.cross_entropy(x_m, target, weight=self.weight)
'--------------------------------FedELC use--------------------------------'


'--------------------------------FedELC use--------------------------------'
class DatasetSplit_ELC(Dataset):
    def __init__(self, dataset, idxs):
        self.images = torch.stack([dataset[i][0] for i in idxs])
        self.labels = torch.tensor([dataset[i][1] for i in idxs])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        return self.images[index], self.labels[index], index

    @property
    def tensor(self):
        return (self.images, self.labels)
'--------------------------------FedELC use--------------------------------'


class LocalUpdate(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.trainset = DatasetSplit(dataset, idxs)
        self.ldr_train = self.train_load()

        self.loss_fn = nn.CrossEntropyLoss()
        self.loss_func = nn.CrossEntropyLoss(reduction='none')

        self.class_num_list = torch.bincount(
            self.trainset.tensor[1].view(-1).long(),
            minlength=self.args.num_classes,
        ).tolist()
        self.noro = LogitAdjust(cls_num_list=self.class_num_list)

    def train_load(self):
        trainset = DataLoader(
            self.trainset,
            batch_size=self.args.local_bs,
            shuffle=True,
            drop_last=len(self.trainset) >= self.args.local_bs,
        )
        return trainset

    def normal_update(self, net, epoch, seed, lr=None):
        net_glob=copy.deepcopy(net)
        net.train()
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(epoch):
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.view(-1).long()

                net.zero_grad()
                log_probs = net(images)

                if self.args.method == 'fedavg':
                    loss = self.loss_fn(log_probs, labels)

                elif self.args.method == 'fedprox':
                    loss = self.loss_fn(log_probs, labels)
                    proximal_term = 0.0
                    for param, param_g in zip(net.parameters(), net_glob.parameters()):
                        proximal_term += ((self.args.beta / 2.) * torch.norm(param - param_g, p=2).pow(2))
                    loss = loss + proximal_term

                elif self.args.method == 'fedelc':
                    loss = self.noro(log_probs, labels)

                else:
                    raise ValueError(f"Unsupported normal-update method: {self.args.method}")

                loss.backward()
                optimizer.step()

                batch_loss.append(loss.item())
            epoch_loss.append(sum(batch_loss)/len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)

    def dal_update(self, net, epoch, seed, lr=None):
        net.train()
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_class_loss = []
        for iter in range(epoch):
            class_stats, class_metrics = {}, {}
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.view(-1).long()

                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)
                loss = loss_sample.mean()
                loss.backward()
                optimizer.step()

                with torch.no_grad():
                    for cls in torch.unique(labels):
                        cls = cls.item()
                        cls_mask = (labels == cls)
                        if cls not in class_stats:
                            class_stats[cls] = []
                        class_stats[cls].append(loss_sample[cls_mask])

            for cls, losses in class_stats.items():
                cls_losses = torch.cat(losses)
                class_metrics[cls] = {'avg_loss': cls_losses.mean().item(), 'count': len(cls_losses)}

            valid_metrics = [metrics for metrics in class_metrics.values()]
            total_count = sum(metrics['count'] for metrics in valid_metrics)
            avg_loss_filler = sum(metrics['avg_loss'] * metrics['count'] for metrics in valid_metrics) / total_count

            class_loss = 0.0
            for cls in range(self.args.num_classes):
                if cls in class_metrics:
                    avg_loss = class_metrics[cls]['avg_loss']
                else:
                    avg_loss = avg_loss_filler
                class_loss += avg_loss
            epoch_class_loss.append(class_loss)
        return net.state_dict(), sum(epoch_class_loss) / len(epoch_class_loss)


class DALUpdate(object):
    def __init__(self, args, dataset, idxs, t0):
        self.args = args
        self.t0 = t0
        self.num_classes = self.args.num_classes
        self.trainset = DatasetSplit(dataset, idxs)
        self.ldr_train = self.train_load()

        self.loss_func = nn.CrossEntropyLoss(reduction='none')
        self.bs = BS()
        self.gce = GCE(num_classes=self.args.num_classes)

    def train_load(self):
        trainset = DataLoader(self.trainset, batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return trainset

    def update_weights(self, net, epoch, seed, lr=None):
        net.train()
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_class_loss = []
        for iter in range(epoch):
            class_stats, class_metrics = {}, {}
            self.q = self.args.qs + (self.args.qe - self.args.qs) * (iter / epoch)
            self.gce = GCE(num_classes=self.num_classes, q=self.q)
            self.lamb = max(0, (iter - self.t0) / (epoch - self.t0))
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.view(-1).long()

                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)

                loss = (
                    self.gce(log_probs, labels)
                    + self.lamb * self.bs(log_probs)
                    / (self.q * np.log(self.num_classes))
                )

                loss.backward()
                optimizer.step()

                with torch.no_grad():
                    for cls in torch.unique(labels):
                        cls = cls.item()
                        cls_mask = (labels == cls)
                        if cls not in class_stats:
                            class_stats[cls] = []
                        class_stats[cls].append(loss_sample[cls_mask])

            for cls, losses in class_stats.items():
                cls_losses = torch.cat(losses)
                class_metrics[cls] = {'avg_loss': cls_losses.mean().item(), 'count': len(cls_losses)}

            valid_metrics = [metrics for metrics in class_metrics.values()]
            total_count = sum(metrics['count'] for metrics in valid_metrics)
            avg_loss_filler = sum(metrics['avg_loss'] * metrics['count'] for metrics in valid_metrics) / total_count

            class_loss = 0.0
            for cls in range(self.args.num_classes):
                if cls in class_metrics:
                    avg_loss = class_metrics[cls]['avg_loss']
                else:
                    avg_loss = avg_loss_filler
                class_loss += avg_loss
            epoch_class_loss.append(class_loss)
        return net.state_dict(), sum(epoch_class_loss) / len(epoch_class_loss)


class ELC(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.trainset = DatasetSplit_ELC(dataset, idxs)
        self.ldr_train = self.train_load()
        self.alpha, self.beta, self.lamda = 0.2, 0.5, 0.1
        self.soft_labels = None

    def train_load(self):
        trainset = DataLoader(self.trainset, batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return trainset

    def elc_update(self, net, epoch, seed, lr=None):
        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        if self.soft_labels is None:
            num_samples = len(self.trainset)
            self.soft_labels = torch.zeros(num_samples, self.args.num_classes)
            all_labels = self.trainset.labels.view(-1).long()
            self.soft_labels[torch.arange(num_samples), all_labels] = 10.0

        epoch_loss = []
        for iter in range(epoch):
            batch_loss = []
            labels_grad = torch.zeros_like(self.soft_labels)
            for batch_idx, (images, labels, indexs) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.view(-1).long()
                soft_labels = self.soft_labels[indexs].to(self.args.device)
                soft_labels.requires_grad_(True)

                net.zero_grad()
                log_probs = net(images)
                pred = F.softmax(log_probs, dim=1)
                Lo = -torch.mean(F.log_softmax(soft_labels, dim=1)[torch.arange(soft_labels.shape[0]), labels])
                Le = -torch.mean(torch.sum(F.log_softmax(log_probs, dim=1) * pred, dim=1))
                Lc = -torch.mean(torch.sum(F.log_softmax(soft_labels, dim=1) * pred, dim=1)) - Le
                loss = Lc / self.args.num_classes + self.alpha * Lo + self.beta * Le / self.args.num_classes

                loss.backward()
                optimizer.step()

                labels_grad[indexs] = soft_labels.grad.detach().cpu()
                del soft_labels

                batch_loss.append(loss.item())
            self.soft_labels = self.soft_labels - self.lamda * labels_grad

            epoch_loss.append(sum(batch_loss) / len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)

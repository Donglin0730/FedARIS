"""Federated semi-supervised comparison methods.

The file implements FedMatch, SAGE, and FixMatch-based combinations in a
shared runner.  Weak predictions are created without hidden labels, confidence
gates are applied before local optimization, and strong augmentation is used
only for accepted unlabeled examples.
"""

import copy
import math
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from util.fedavg import FedAvg
from util.metrics import ClassificationTracker
from util.util import write_log


SSL_METHODS = {
    'fedmatch',
    'sage',
    'fedavg_fixmatch',
    'fedcorr_fixmatch',
}


# FedMatch state -----------------------------------------------------------


@dataclass
class FedMatchState:
    """The disjoint FedMatch parameters and non-trainable model buffers."""

    sigma: dict
    psi: dict
    buffers: dict

    def to(self, device):
        return FedMatchState(
            sigma=_to_device_state(self.sigma, device),
            psi=_to_device_state(self.psi, device),
            buffers=_to_device_state(self.buffers, device),
        )

    def cpu(self):
        return FedMatchState(
            sigma=_cpu_state_dict(self.sigma),
            psi=_cpu_state_dict(self.psi),
            buffers=_cpu_state_dict(self.buffers),
        )


@dataclass
class FedMatchClientResult:
    state: FedMatchState
    loss: float
    stats: dict


# Dataset views ------------------------------------------------------------


class LabeledSubset(Dataset):
    def __init__(self, dataset, indices):
        self.dataset = dataset
        self.indices = sorted(int(index) for index in indices)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, index):
        return self.dataset[self.indices[index]]


class TransformedSubset(LabeledSubset):
    def __init__(self, dataset, indices, transform_attribute):
        transformed = copy.copy(dataset)
        transform = getattr(dataset, transform_attribute, None)
        if transform is not None and hasattr(transformed, 'transform'):
            transformed.transform = transform
        super().__init__(transformed, indices)


class UnlabeledViews(Dataset):
    def __init__(
            self, dataset, indices,
            weak_transform_attribute='ssl_weak_transform'):
        self.indices = sorted(int(index) for index in indices)
        weak_transform = getattr(dataset, weak_transform_attribute, None)
        strong_transform = getattr(dataset, 'ssl_strong_transform', None)
        self.weak_dataset = copy.copy(dataset)
        self.strong_dataset = copy.copy(dataset)
        if weak_transform is not None and hasattr(dataset, 'transform'):
            self.weak_dataset.transform = weak_transform
        if strong_transform is not None and hasattr(dataset, 'transform'):
            self.strong_dataset.transform = strong_transform

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, index):
        global_index = self.indices[index]
        weak, _ = self.weak_dataset[global_index]
        strong, _ = self.strong_dataset[global_index]
        return weak, strong, global_index


def _next_batch(loader, iterator):
    if loader is None:
        return None, iterator
    try:
        return next(iterator), iterator
    except StopIteration:
        iterator = iter(loader)
        return next(iterator), iterator


def _rampup(round_idx, rampup_rounds):
    if rampup_rounds <= 0:
        return 1.0
    return float(np.clip((round_idx + 1) / rampup_rounds, 0.0, 1.0))


# Only counts used in the training log are retained. Hidden labels are never
# read by a baseline implementation.
def _new_pseudo_stats():
    return {'pseudo_total': 0, 'pseudo_accepted': 0}


def _record_pseudo_batch(stats, accepted):
    stats['pseudo_total'] += int(accepted.numel())
    stats['pseudo_accepted'] += int(accepted.sum().item())


# Shared model-state utilities --------------------------------------------


def _cpu_state_dict(state_dict):
    return {
        key: value.detach().cpu().clone()
        for key, value in state_dict.items()
    }


def _forward_logits(model, inputs):
    outputs = model(inputs)
    if isinstance(outputs, (tuple, list)):
        outputs = outputs[-1]
    return outputs


def _model_parameter_state(model):
    return {
        name: parameter.detach().clone()
        for name, parameter in model.named_parameters()
    }


def _model_buffer_state(model):
    return {
        name: buffer.detach().clone()
        for name, buffer in model.named_buffers()
    }


def _to_device_state(state, device):
    return {
        name: value.detach().to(device).clone()
        for name, value in state.items()
    }


def _average_tensor_states(states):
    if not states:
        raise ValueError('Cannot average an empty state list.')
    averaged = {}
    for name in states[0]:
        values = [state[name] for state in states]
        if values[0].is_floating_point():
            averaged[name] = torch.stack(values).mean(dim=0)
        else:
            averaged[name] = values[0].clone()
    return averaged


def _load_fedmatch_state(
        model, state, *, sparse_psi=False, threshold=0.0):
    """Materialize theta = sigma + psi into a regular PyTorch model."""
    with torch.no_grad():
        for name, parameter in model.named_parameters():
            psi_value = state.psi[name]
            if sparse_psi:
                psi_value = torch.where(
                    psi_value.abs() > threshold,
                    psi_value,
                    torch.zeros_like(psi_value),
                )
            parameter.copy_(state.sigma[name] + psi_value)
        for name, buffer in model.named_buffers():
            buffer.copy_(state.buffers[name])


def _capture_model_buffers(model, buffers):
    for name, buffer in model.named_buffers():
        buffers[name] = buffer.detach().clone()


def _select_fedmatch_helpers(
        bank, client_id, round_idx, count, interval):
    if count <= 0 or client_id not in bank:
        return []
    if (round_idx + 1) % interval != 0:
        return []
    query = bank[client_id]['embedding']
    candidates = []
    for helper_id, entry in bank.items():
        if helper_id == client_id:
            continue
        distance = torch.linalg.vector_norm(
            query - entry['embedding']).item()
        candidates.append((distance, helper_id, entry['state'].psi))
    candidates.sort(key=lambda item: (item[0], item[1]))
    return [state for _, _, state in candidates[:count]]


def _sage_pseudo_targets(local_logits, global_logits, threshold, kappa):
    local_probabilities = F.softmax(local_logits.detach(), dim=1)
    global_probabilities = F.softmax(global_logits.detach(), dim=1)
    local_confidence, local_targets = local_probabilities.max(dim=1)
    global_confidence, global_targets = global_probabilities.max(dim=1)
    local_mask = local_confidence.ge(threshold)
    global_mask = global_confidence.ge(threshold)
    discrepancy = (local_confidence - global_confidence).abs().clamp(
        min=1e-6, max=1.0)
    local_weight = torch.exp(-kappa * discrepancy).clamp(
        min=1e-6, max=1.0)
    local_one_hot = F.one_hot(
        local_targets, local_logits.shape[1]).float()
    global_one_hot = F.one_hot(
        global_targets, global_logits.shape[1]).float()
    soft_targets = torch.where(
        local_mask.unsqueeze(1),
        local_weight.unsqueeze(1) * local_one_hot
        + (1.0 - local_weight).unsqueeze(1) * global_one_hot,
        global_one_hot,
    )
    accepted = local_mask | global_mask
    selected_confidence = torch.where(
        local_mask, local_confidence, global_confidence)
    return soft_targets, accepted, selected_confidence


# SAGE and FixMatch clients ------------------------------------------------


class SSLClientUpdate:
    def __init__(self, args, dataset, labeled_indices, unlabeled_indices,
                 method):
        if method == 'fedmatch':
            raise ValueError(
                'FedMatch must use FedMatchClientUpdate so sigma and psi '
                'remain disjoint.')
        self.args = args
        self.method = method
        self.labeled_loader = self._loader(
            LabeledSubset(dataset, labeled_indices))
        self.unlabeled_loader = self._loader(
            UnlabeledViews(dataset, unlabeled_indices))

    def _loader(self, dataset):
        if len(dataset) == 0:
            return None
        return DataLoader(
            dataset,
            batch_size=self.args.local_bs,
            shuffle=True,
            drop_last=False,
            num_workers=self.args.ssl_num_workers,
        )

    def _unlabeled_objective(self, student, teacher, weak, strong):
        with torch.no_grad():
            global_logits = _forward_logits(teacher, weak)
            global_probabilities = F.softmax(
                global_logits / self.args.ssl_temperature, dim=1)
            global_confidence, global_targets = global_probabilities.max(dim=1)

        if self.method in {
                'fedavg_fixmatch', 'fedcorr_fixmatch'}:
            accepted = global_confidence.ge(self.args.ssl_threshold)
            strong_logits = _forward_logits(student, strong)
            per_sample = F.cross_entropy(
                strong_logits, global_targets, reduction='none')
            loss = (per_sample * accepted.float()).mean()
            return loss, global_targets, accepted, global_confidence

        if self.method == 'sage':
            weak_logits = _forward_logits(student, weak)
            strong_logits = _forward_logits(student, strong)
            soft_targets, accepted, confidence = _sage_pseudo_targets(
                weak_logits / self.args.ssl_temperature,
                global_logits / self.args.ssl_temperature,
                self.args.ssl_threshold,
                self.args.sage_kappa,
            )
            per_sample = F.kl_div(
                F.log_softmax(strong_logits, dim=1),
                soft_targets,
                reduction='none',
            ).sum(dim=1)
            loss = (per_sample * accepted.float()).mean()
            targets = soft_targets.argmax(dim=1)
            return loss, targets, accepted, confidence

        raise ValueError(f'Unsupported SSL baseline: {self.method}')

    def _supervised_objective(self, logits, labels):
        return F.cross_entropy(logits, labels)

    def train(self, student, global_model, round_idx):
        if self.labeled_loader is None and self.unlabeled_loader is None:
            raise ValueError('SSL client has no local data.')
        student = student.to(self.args.device)
        student.train()
        teacher = copy.deepcopy(global_model).to(self.args.device)
        teacher.eval()
        for parameter in teacher.parameters():
            parameter.requires_grad_(False)
        optimizer = torch.optim.SGD(
            student.parameters(),
            lr=self.args.lr,
            momentum=self.args.momentum,
            weight_decay=self.args.ssl_weight_decay,
        )
        lambda_u = self.args.ssl_lambda_u * _rampup(
            round_idx, self.args.ssl_rampup_rounds)
        stats = _new_pseudo_stats()
        losses = []
        labeled_steps = len(self.labeled_loader) if self.labeled_loader else 0
        unlabeled_steps = (
            len(self.unlabeled_loader) if self.unlabeled_loader else 0)
        steps = max(labeled_steps, unlabeled_steps)

        for local_epoch in range(self.args.local_ep):
            labeled_iterator = (
                iter(self.labeled_loader) if self.labeled_loader else None)
            unlabeled_iterator = (
                iter(self.unlabeled_loader) if self.unlabeled_loader else None)
            for _ in range(steps):
                optimizer.zero_grad(set_to_none=True)
                terms = []
                labeled_batch, labeled_iterator = _next_batch(
                    self.labeled_loader, labeled_iterator)
                if labeled_batch is not None:
                    images, labels = labeled_batch
                    images = images.to(self.args.device)
                    labels = labels.to(self.args.device).view(-1).long()
                    labeled_logits = _forward_logits(student, images)
                    terms.append(self._supervised_objective(
                        labeled_logits, labels))

                unlabeled_batch, unlabeled_iterator = _next_batch(
                    self.unlabeled_loader, unlabeled_iterator)
                if unlabeled_batch is not None:
                    weak, strong, _ = unlabeled_batch
                    weak = weak.to(self.args.device)
                    strong = strong.to(self.args.device)
                    unsupervised, _, accepted, _ = (
                        self._unlabeled_objective(
                            student, teacher, weak, strong))
                    if lambda_u > 0:
                        terms.append(lambda_u * unsupervised)

                    _record_pseudo_batch(stats, accepted)

                if not terms:
                    continue
                loss = sum(terms)
                loss.backward()
                optimizer.step()
                losses.append(float(loss.item()))

        average_loss = float(np.mean(losses)) if losses else 0.0
        return student.state_dict(), average_loss, stats


# FedMatch client ----------------------------------------------------------


class FedMatchClientUpdate:
    """PyTorch port of FedMatch's labels-at-client local algorithm."""

    def __init__(self, args, dataset, labeled_indices, unlabeled_indices,
                 helper_psi_states=None):
        self.args = args
        self.helper_psi_states = list(helper_psi_states or [])
        self.labeled_count = len(labeled_indices)
        self.unlabeled_count = len(unlabeled_indices)
        labeled_dataset = TransformedSubset(
            dataset, labeled_indices, 'ssl_plain_transform')
        unlabeled_dataset = UnlabeledViews(
            dataset,
            unlabeled_indices,
            weak_transform_attribute='ssl_plain_transform',
        )
        if self.labeled_count:
            self.steps = max(
                round(self.labeled_count / self.args.local_bs), 1)
        else:
            self.steps = max(
                math.ceil(self.unlabeled_count / self.args.local_bs), 1)
        unlabeled_batch_size = max(
            math.ceil(self.unlabeled_count / self.steps), 1)
        self.labeled_loader = self._loader(
            labeled_dataset, self.args.local_bs)
        self.unlabeled_loader = self._loader(
            unlabeled_dataset, unlabeled_batch_size)

    def _loader(self, dataset, batch_size):
        if len(dataset) == 0:
            return None
        return DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=self.args.ssl_num_workers,
        )

    def _build_helpers(self, template, client_state):
        helpers = []
        for helper_psi_state in self.helper_psi_states:
            helper = copy.deepcopy(template).to(self.args.device)
            helper_state = FedMatchState(
                sigma=client_state.sigma,
                psi=_to_device_state(
                    helper_psi_state, self.args.device),
                buffers=client_state.buffers,
            )
            _load_fedmatch_state(
                helper,
                helper_state,
                sparse_psi=True,
                threshold=self.args.fedmatch_l1_threshold,
            )
            helper.eval()
            for parameter in helper.parameters():
                parameter.requires_grad_(False)
            helpers.append(helper)
        return helpers

    def _update_component(
            self, component, model, sigma, psi, *, unsupervised=False):
        with torch.no_grad():
            for name, parameter in model.named_parameters():
                gradient = (
                    parameter.grad.detach().clone()
                    if parameter.grad is not None
                    else torch.zeros_like(parameter))
                if self.args.fedmatch_weight_decay:
                    gradient.add_(
                        parameter.detach(),
                        alpha=self.args.fedmatch_weight_decay,
                    )
                if unsupervised:
                    gradient.add_(
                        psi[name].sign(),
                        alpha=self.args.fedmatch_lambda_l1,
                    )
                    gradient.add_(
                        psi[name] - sigma[name],
                        alpha=2.0 * self.args.fedmatch_lambda_l2,
                    )
                component[name].add_(
                    gradient, alpha=-self.args.fedmatch_lr)

    def _regularization_value(self, sigma, psi):
        l1 = torch.zeros((), device=self.args.device)
        l2 = torch.zeros((), device=self.args.device)
        for name in psi:
            l1 = l1 + psi[name].abs().sum()
            l2 = l2 + (sigma[name] - psi[name]).square().sum()
        return (
            self.args.fedmatch_lambda_l1 * l1
            + self.args.fedmatch_lambda_l2 * l2)

    def _unlabeled_objective(self, student, helpers, plain, strong, round_idx):
        local_logits = _forward_logits(student, plain)
        local_probabilities = F.softmax(
            local_logits / self.args.ssl_temperature, dim=1)
        confidence, local_targets = local_probabilities.detach().max(dim=1)
        accepted = confidence.ge(self.args.fedmatch_confidence)
        votes = F.one_hot(
            local_targets, self.args.num_classes).float()
        helper_probabilities = []
        with torch.no_grad():
            for helper in helpers:
                probabilities = F.softmax(
                    _forward_logits(helper, plain)
                    / self.args.ssl_temperature,
                    dim=1,
                )
                helper_probabilities.append(probabilities)
                votes += F.one_hot(
                    probabilities.argmax(dim=1),
                    self.args.num_classes,
                ).float()
        agreement_targets = votes.argmax(dim=1)
        loss = torch.zeros((), device=self.args.device)
        if accepted.any():
            strong_logits = _forward_logits(student, strong[accepted])
            loss = loss + self.args.fedmatch_lambda_agreement \
                * F.cross_entropy(
                    strong_logits, agreement_targets[accepted])
            if helper_probabilities and round_idx > 0:
                local_log_probabilities = F.log_softmax(
                    local_logits[accepted], dim=1)
                inter_client = torch.zeros((), device=self.args.device)
                for probabilities in helper_probabilities:
                    inter_client = inter_client + F.kl_div(
                        local_log_probabilities,
                        probabilities[accepted],
                        reduction='batchmean',
                    )
                loss = loss + self.args.fedmatch_lambda_inter \
                    * inter_client / len(helper_probabilities)
        return loss, agreement_targets, accepted, confidence

    def train(self, template, global_state, round_idx):
        if self.labeled_loader is None and self.unlabeled_loader is None:
            raise ValueError('FedMatch client has no local data.')
        student = copy.deepcopy(template).to(self.args.device)
        student.train()
        state = global_state.to(self.args.device)
        _load_fedmatch_state(student, state)
        helpers = self._build_helpers(template, state)
        stats = _new_pseudo_stats()
        losses = []

        for _ in range(self.args.local_ep):
            labeled_iterator = (
                iter(self.labeled_loader) if self.labeled_loader else None)
            unlabeled_iterator = (
                iter(self.unlabeled_loader) if self.unlabeled_loader else None)
            for _ in range(self.steps):
                labeled_batch, labeled_iterator = _next_batch(
                    self.labeled_loader, labeled_iterator)
                if labeled_batch is not None:
                    images, labels = labeled_batch
                    images = images.to(self.args.device)
                    labels = labels.to(self.args.device).view(-1).long()
                    student.zero_grad(set_to_none=True)
                    supervised_loss = self.args.fedmatch_lambda_s \
                        * F.cross_entropy(
                            _forward_logits(student, images), labels)
                    supervised_loss.backward()
                    _capture_model_buffers(student, state.buffers)
                    # Supervised labels update sigma while psi stays fixed.
                    self._update_component(
                        state.sigma,
                        student,
                        state.sigma,
                        state.psi,
                        unsupervised=False,
                    )
                    _load_fedmatch_state(student, state)
                    losses.append(float(supervised_loss.item()))

                unlabeled_batch, unlabeled_iterator = _next_batch(
                    self.unlabeled_loader, unlabeled_iterator)
                if unlabeled_batch is None:
                    continue
                plain, strong, _ = unlabeled_batch
                plain = plain.to(self.args.device)
                strong = strong.to(self.args.device)
                student.zero_grad(set_to_none=True)
                objective, _, accepted, _ = (
                    self._unlabeled_objective(
                        student, helpers, plain, strong, round_idx))
                regularization = self._regularization_value(
                    state.sigma, state.psi)
                if objective.requires_grad:
                    objective.backward()
                _capture_model_buffers(student, state.buffers)
                # Pseudo-label objectives update psi while sigma stays fixed.
                self._update_component(
                    state.psi,
                    student,
                    state.sigma,
                    state.psi,
                    unsupervised=True,
                )
                _load_fedmatch_state(student, state)
                losses.append(float(
                    objective.detach().item()
                    + regularization.detach().item()))

                _record_pseudo_batch(stats, accepted)

        for helper in helpers:
            helper.cpu()
        average_loss = float(np.mean(losses)) if losses else 0.0
        return FedMatchClientResult(
            state=state.cpu(),
            loss=average_loss,
            stats=stats,
        )


def _fedmatch_model_embedding(
        template, state, probe, args):
    model = copy.deepcopy(template).to(args.device)
    _load_fedmatch_state(
        model,
        state.to(args.device),
        sparse_psi=True,
        threshold=args.fedmatch_l1_threshold,
    )
    model.eval()
    with torch.no_grad():
        embedding = F.softmax(
            _forward_logits(model, probe.to(args.device)), dim=1)
    model.cpu()
    return embedding.squeeze(0).detach().cpu()


# Round orchestration ------------------------------------------------------


def _set_fedmatch_global_model(model, state, args):
    device = next(model.parameters()).device
    _load_fedmatch_state(
        model,
        state.to(device),
        sparse_psi=True,
        threshold=args.fedmatch_l1_threshold,
    )


def _run_fedmatch_baseline(
        args, dataset_train, dataset_test, labeled_users, unlabeled_users,
        net_glob, result_file, start_round, rounds,
        valid_clients, clients_per_round):
    classification = ClassificationTracker(result_file, args.num_classes)
    initial_sigma = _cpu_state_dict(_model_parameter_state(net_glob))
    global_state = FedMatchState(
        sigma=initial_sigma,
        psi={
            name: value * args.fedmatch_psi_factor
            for name, value in initial_sigma.items()
        },
        buffers=_cpu_state_dict(_model_buffer_state(net_glob)),
    )
    _set_fedmatch_global_model(net_glob, global_state, args)
    probe_dataset = TransformedSubset(
        dataset_train, [0], 'ssl_plain_transform')
    sample, _ = probe_dataset[0]
    generator = torch.Generator().manual_seed(args.seed + 1701)
    probe = torch.randn(
        (1, *sample.shape), generator=generator, dtype=sample.dtype)
    helper_bank = {}

    write_log(
        'fedmatch reproduction: scope=algorithm_level_unified_protocol, '
        'scenario=labels_at_client, confidence=%.4f, helpers=%d, '
        'helper_interval=%d, lambda_s=%.6g, lambda_a=%.6g, '
        'lambda_iccs=%.6g, lambda_l1=%.6g, lambda_l2=%.6g, '
        'psi_factor=%.4f, aggregation=uniform'
        % (
            args.fedmatch_confidence,
            args.fedmatch_num_helpers,
            args.fedmatch_helper_interval,
            args.fedmatch_lambda_s,
            args.fedmatch_lambda_agreement,
            args.fedmatch_lambda_inter,
            args.fedmatch_lambda_l1,
            args.fedmatch_lambda_l2,
            args.fedmatch_psi_factor,
        ),
        result_file,
    )

    for offset in range(rounds):
        round_idx = start_round + offset
        selected = np.random.choice(
            valid_clients,
            clients_per_round,
            replace=False,
        ).astype(int).tolist()
        local_results = []

        for client_id in selected:
            helper_psi_states = _select_fedmatch_helpers(
                helper_bank,
                client_id,
                round_idx,
                args.fedmatch_num_helpers,
                args.fedmatch_helper_interval,
            )
            updater = FedMatchClientUpdate(
                args,
                dataset_train,
                labeled_users[client_id],
                unlabeled_users[client_id],
                helper_psi_states=helper_psi_states,
            )
            result = updater.train(net_glob, global_state, offset)
            local_results.append((client_id, result))

        global_state = FedMatchState(
            sigma=_average_tensor_states([
                result.state.sigma for _, result in local_results]),
            psi=_average_tensor_states([
                result.state.psi for _, result in local_results]),
            buffers=_average_tensor_states([
                result.state.buffers for _, result in local_results]),
        )
        _set_fedmatch_global_model(net_glob, global_state, args)

        for client_id, result in local_results:
            helper_bank[client_id] = {
                'state': result.state,
                'embedding': _fedmatch_model_embedding(
                    net_glob, result.state, probe, args,
                ),
            }

        client_stats = [result.stats for _, result in local_results]
        metrics = classification.record(
            round_idx,
            copy.deepcopy(net_glob).to(args.device),
            dataset_test,
            args,
        )
        total = sum(stats['pseudo_total'] for stats in client_stats)
        accepted = sum(stats['pseudo_accepted'] for stats in client_stats)
        mean_local_loss = float(np.mean([
            result.loss for _, result in local_results]))
        print(
            f'fedmatch round {round_idx}: local_loss={mean_local_loss:.4f}, '
            f'loss={metrics["loss"]:.4f}, '
            f'acc={metrics["accuracy"]:.4f}, '
            f'macro_f1={metrics["macro_f1"]:.4f}, '
            f'pseudo={accepted}/{total}'
        )

    classification.finalize()
    return {
        'history': classification.history,
        'model': net_glob,
    }


def run_ssl_baseline(args, dataset_train, dataset_test, labeled_users,
                     unlabeled_users, net_glob, result_file,
                     start_round=0, total_rounds=None):
    method = args.method
    if method not in SSL_METHODS:
        raise ValueError(f'Unsupported SSL baseline: {method}')
    rounds = args.rounds if total_rounds is None else int(total_rounds)
    valid_clients = [
        client_id for client_id in sorted(labeled_users)
        if labeled_users[client_id] or unlabeled_users[client_id]
    ]
    clients_per_round = min(
        max(int(args.num_users * args.frac1), 1), len(valid_clients))
    if method == 'fedmatch':
        return _run_fedmatch_baseline(
            args,
            dataset_train,
            dataset_test,
            labeled_users,
            unlabeled_users,
            net_glob,
            result_file,
            start_round,
            rounds,
            valid_clients,
            clients_per_round,
        )
    classification = ClassificationTracker(result_file, args.num_classes)

    write_log(
        'ssl config: method=%s, threshold=%.4f, lambda_u=%.4f, '
        'temperature=%.4f, helpers=%d'
        % (
            method,
            args.ssl_threshold,
            args.ssl_lambda_u,
            args.ssl_temperature,
            0,
        ),
        result_file,
    )
    if method == 'sage':
        write_log(
            'sage reproduction: scope=algorithm_level_unified_protocol, '
            'components=CPG+CDSC, kappa=%.10f, '
            'official_source=baseline_materials/source/SAGE'
            % args.sage_kappa,
            result_file,
        )

    for offset in range(rounds):
        round_idx = start_round + offset
        selected = np.random.choice(
            valid_clients,
            clients_per_round,
            replace=False,
        ).astype(int).tolist()
        local_weights = []
        local_losses = []
        data_lengths = []
        client_stats = []

        for client_id in selected:
            updater = SSLClientUpdate(
                args,
                dataset_train,
                labeled_users[client_id],
                unlabeled_users[client_id],
                method,
            )
            weights, loss, stats = updater.train(
                copy.deepcopy(net_glob), net_glob, offset)
            local_weights.append(copy.deepcopy(weights))
            local_losses.append(loss)
            data_lengths.append(
                len(labeled_users[client_id])
                + len(unlabeled_users[client_id]))
            client_stats.append(stats)

        averaged = FedAvg(local_weights, data_lengths, local_losses)
        net_glob.load_state_dict(copy.deepcopy(averaged))
        metrics = classification.record(
            round_idx,
            copy.deepcopy(net_glob).to(args.device),
            dataset_test,
            args,
        )
        total = sum(stats['pseudo_total'] for stats in client_stats)
        accepted = sum(stats['pseudo_accepted'] for stats in client_stats)
        print(
            f'{method} round {round_idx}: loss={metrics["loss"]:.4f}, '
            f'acc={metrics["accuracy"]:.4f}, '
            f'macro_f1={metrics["macro_f1"]:.4f}, '
            f'pseudo={accepted}/{total}'
        )

    classification.finalize()
    return {
        'history': classification.history,
        'model': net_glob,
    }

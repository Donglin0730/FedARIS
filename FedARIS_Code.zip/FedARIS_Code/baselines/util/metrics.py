"""Shared evaluation code for all comparison methods."""

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from util.util import write_log


def evaluate_classification(model, dataset, args):
    model.eval()
    loader = DataLoader(dataset, batch_size=100, shuffle=False, num_workers=0)
    confusion = torch.zeros(
        (args.num_classes, args.num_classes), dtype=torch.long)
    total_loss = 0.0
    total = 0
    loss_fn = nn.CrossEntropyLoss(reduction='sum')

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args.device)
            labels = labels.to(args.device).view(-1).long()
            logits = model(images)
            total_loss += float(loss_fn(logits, labels).item())
            predictions = logits.argmax(dim=1)
            encoded = labels * args.num_classes + predictions
            confusion += torch.bincount(
                encoded.cpu(), minlength=args.num_classes ** 2
            ).reshape(args.num_classes, args.num_classes)
            total += labels.numel()

    true_positive = confusion.diag().double()
    support = confusion.sum(dim=1).double()
    predicted = confusion.sum(dim=0).double()
    recall = torch.where(
        support > 0, true_positive / support, torch.zeros_like(support))
    precision = torch.where(
        predicted > 0, true_positive / predicted, torch.zeros_like(predicted))
    f1 = torch.where(
        precision + recall > 0,
        2 * precision * recall / (precision + recall),
        torch.zeros_like(recall),
    )
    valid = support > 0
    return {
        'loss': total_loss / total if total else 0.0,
        'accuracy': float(true_positive.sum().item() / total) if total else 0.0,
        'macro_f1': float(f1[valid].mean().item()) if valid.any() else 0.0,
    }


def summarize_history(history, window_size=10):
    if not history:
        return {}
    window = history[-min(window_size, len(history)):]
    return {
        'last_accuracy': float(history[-1]['accuracy']),
        'last_macro_f1': float(history[-1]['macro_f1']),
        'last10_accuracy': float(np.mean([row['accuracy'] for row in window])),
        'last10_macro_f1': float(np.mean([row['macro_f1'] for row in window])),
        'best_accuracy': float(max(row['accuracy'] for row in history)),
    }


class ClassificationTracker:
    def __init__(self, result_file, num_classes=None):
        del num_classes
        self.result_file = result_file
        self.history = []
        write_log('round,loss,acc,macro_f1', result_file)

    def record(self, round_idx, model, dataset, args):
        metrics = evaluate_classification(model, dataset, args)
        self.history.append(metrics)
        write_log(
            f'{round_idx},{metrics["loss"]:.6f},'
            f'{metrics["accuracy"]:.6f},{metrics["macro_f1"]:.6f}',
            self.result_file,
        )
        return metrics

    def finalize(self):
        summary = summarize_history(self.history)
        if summary:
            write_log(
                'last10 acc={last10_accuracy:.6f}, '
                'macro_f1={last10_macro_f1:.6f}, '
                'best_acc={best_accuracy:.6f}'.format(**summary),
                self.result_file,
            )
        return summary

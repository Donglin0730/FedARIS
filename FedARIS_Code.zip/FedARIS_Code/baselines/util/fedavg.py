import copy
import torch
import numpy as np


def _weighted_average(weights, coefficients):
    if not weights:
        raise ValueError('At least one client update is required.')
    if len(weights) != len(coefficients):
        raise ValueError('Client updates and aggregation weights must align.')
    coefficients = np.asarray(coefficients, dtype=np.float64)
    total = float(coefficients.sum())
    if not np.isfinite(total) or total <= 0:
        raise ValueError('Aggregation weights must have a positive finite sum.')

    averaged = copy.deepcopy(weights[0])
    discrete_source = int(np.argmax(coefficients))
    for key, target in averaged.items():
        if not (target.is_floating_point() or target.is_complex()):
            averaged[key] = weights[discrete_source][key].clone()
            continue
        target = target * float(coefficients[0])
        for index in range(1, len(weights)):
            target = target + weights[index][key] * float(coefficients[index])
        averaged[key] = target / total
    return averaged


def FedAvg(w, dict_len, value):
    del value
    return _weighted_average(w, dict_len)


def ImpFedAvg(w, dict_len, value):
    weight = [0] * len(w)
    min_value = min(value)
    max_value = max(value)
    value_range = max_value - min_value
    normalized = (
        [(item - min_value) / value_range for item in value]
        if value_range > 1e-12 else [0.0] * len(value)
    )
    for i in range(len(weight)):
        weight[i] = dict_len[i] * np.exp(-normalized[i])
    return _weighted_average(w, weight)


def DeAgg(select, client_datalen, update_dict, select_clean, select_noisy):

    distance = np.zeros(len(select))
    weight = [client_datalen[i] / sum(client_datalen) for i in range(len(select))]
    for i in select_noisy:
        min_dist = np.inf
        for j in select_clean:
            dist = model_dist(update_dict[i], update_dict[j])
            min_dist = dist if dist < min_dist else min_dist
        distance[i] = min_dist

    distance_norm = distance / np.max(distance) if np.max(distance) > 1e-6 else np.zeros_like(distance)
    weight = weight * np.exp(-distance_norm)
    return _weighted_average(update_dict, weight)


def model_dist(w_1, w_2):
    assert w_1.keys() == w_2.keys(), "Keys mismatch."
    dist_total = torch.zeros(1).float()
    for key in w_1.keys():
        if "int" in str(w_1[key].dtype):
            continue
        dist = torch.norm(w_1[key] - w_2[key])
        dist_total += dist.cpu()
    return dist_total.cpu().item()

import numpy as np
from torchvision import datasets, transforms

from util.sampling import iid_sampling, non_iid_dirichlet_sampling


def _attach_ssl_views(
        dataset, weak_transform, strong_transform, plain_transform=None):
    """Attach plain, weak and strong views used by FedMatch/SAGE/FixMatch."""
    dataset.ssl_plain_transform = plain_transform or weak_transform
    dataset.ssl_weak_transform = weak_transform
    dataset.ssl_strong_transform = strong_transform
    return dataset


def get_dataset(args):
    if args.dataset == 'fmnist':
        data_path = '../data/fashionmnist'
        args.num_classes = 10
        args.model = 'lenet'
        trans = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307), (0.3081))
        ])
        trans_strong = transforms.Compose([
            transforms.RandomCrop(28, padding=2),
            transforms.RandomHorizontalFlip(),
            transforms.RandAugment(
                num_ops=args.ssl_randaug_ops,
                magnitude=args.ssl_randaug_magnitude),
            transforms.ToTensor(),
            transforms.Normalize((0.1307), (0.3081)),
        ])
        dataset_train = datasets.FashionMNIST(
            data_path, train=True, download=True, transform=trans)
        _attach_ssl_views(dataset_train, trans, trans_strong, trans)
        dataset_test = datasets.FashionMNIST(
            data_path, train=False, download=True, transform=trans)
        n_train = len(dataset_train)
        y_train = np.array(dataset_train.targets)
    elif args.dataset == 'cifar10':
        data_path = '../data/cifar10'
        args.num_classes = 10
        args.model = 'resnet18'
        trans_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_val = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_strong = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.RandAugment(
                num_ops=args.ssl_randaug_ops,
                magnitude=args.ssl_randaug_magnitude),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]),
        ])
        dataset_train = datasets.CIFAR10(
            data_path, train=True, download=True, transform=trans_train)
        _attach_ssl_views(
            dataset_train, trans_train, trans_strong, trans_val)
        dataset_test = datasets.CIFAR10(data_path, train=False, download=True, transform=trans_val)
        n_train = len(dataset_train)
        y_train = np.array(dataset_train.targets)
    elif args.dataset == 'cifar100':
        data_path = '../data/cifar100'
        args.num_classes = 100
        args.model = 'resnet34'
        trans_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.507, 0.487, 0.441], std=[0.267, 0.256, 0.276])
        ])
        trans_val = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.507, 0.487, 0.441], std=[0.267, 0.256, 0.276])
        ])
        trans_strong = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.RandAugment(
                num_ops=args.ssl_randaug_ops,
                magnitude=args.ssl_randaug_magnitude),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.507, 0.487, 0.441],
                std=[0.267, 0.256, 0.276]),
        ])
        dataset_train = datasets.CIFAR100(
            data_path, train=True, download=True, transform=trans_train)
        _attach_ssl_views(
            dataset_train, trans_train, trans_strong, trans_val)
        dataset_test = datasets.CIFAR100(
            data_path, train=False, download=True, transform=trans_val)
        n_train = len(dataset_train)
        y_train = np.array(dataset_train.targets)
    elif args.dataset == 'animal10':
        args.num_classes = 10
        args.model = 'resnet34'
        trans_train = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.RandomCrop(32),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_val = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        trans_strong = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.RandAugment(
                num_ops=args.ssl_randaug_ops,
                magnitude=args.ssl_randaug_magnitude),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]),
        ])
        dataset_train = datasets.ImageFolder(
            '../data/animal10/train_dataset', transform=trans_train)
        _attach_ssl_views(
            dataset_train, trans_train, trans_strong, trans_val)
        dataset_test = datasets.ImageFolder('../data/animal10/val_dataset', transform=trans_val)
        n_train = len(dataset_train)
        y_train = np.array(dataset_train.targets)
    else:
        exit('Error: unrecognized dataset')

    if args.iid:
        dict_users = iid_sampling(n_train, args.num_users, args.seed)
    else:
        dict_users = non_iid_dirichlet_sampling(
            y_train,
            args.num_classes,
            args.non_iid_prob_class,
            args.num_users,
            args.seed,
            args.alpha_dirichlet,
            min_client_size=args.local_bs,
        )

    return dataset_train, dataset_test, y_train, dict_users
